module CoreJavaAssignment2 {
}