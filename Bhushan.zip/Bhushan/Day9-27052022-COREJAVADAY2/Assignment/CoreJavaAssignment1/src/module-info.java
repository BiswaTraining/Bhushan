module CoreJavaAssignment1 {
}