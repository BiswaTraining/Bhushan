package com.assignment1;

import java.util.Scanner;

public class LoginModule {

	public static void main(String[] args) {
		Customer[] listOfCustomers = new Customer[3];
		listOfCustomers[0]=new Customer("admin1","password1");
		listOfCustomers[1]=new Customer("admin2","password2");
		listOfCustomers[2]=new Customer("admin3","password3");
		
		Product[] listOfProducts = new Product[5];
		listOfProducts[0]= new Product(1,"IPhone 12",75000);
		listOfProducts[1]= new Product(2,"IPhone 12 Pro Max",95000);
		listOfProducts[2]= new Product(3,"IPhone 11",55000);
		listOfProducts[3]= new Product(4,"IPhOne XR",45000);
		listOfProducts[4]= new Product(5,"IPhOne X",35000);
		
		Scanner input = new Scanner(System.in);
		System.out.println("--------------------Welcome to MyShopping Application----------------------------");
		System.out.println("Enter the username");
		String userName=input.next();
		System.out.println("Enter the password");
		String password=input.next();
		boolean isValid=false;
		for (int i = 0; i < listOfCustomers.length; i++) {
			if(listOfCustomers[i].getUserName().equalsIgnoreCase(userName) && listOfCustomers[i].getPassword().equalsIgnoreCase(password)) {
				System.out.println("Login Successful.....");
				isValid=true;
				for(int j=0;j<listOfProducts.length;j++) {
					System.out.println("ProductId "+listOfProducts[j].getProductId()+" Product Name "+listOfProducts[j].getProductName()+" Product Price "+listOfProducts[j].getProductPrice());
				}
			}
		}
		if(!isValid) {
			System.out.println("Wrong credentials");
		}
	}

}
