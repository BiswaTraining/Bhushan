package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=ConnectionTestDatabase;user=sa;password=password_123");
			System.out.println("Connected");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}
}
