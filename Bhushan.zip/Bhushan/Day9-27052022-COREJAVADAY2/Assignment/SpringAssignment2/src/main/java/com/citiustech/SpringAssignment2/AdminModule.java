package com.citiustech.SpringAssignment2;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.dao.AdminOperationsDao;
import com.citiustech.model.Products;
import com.citiustech.util.LoginModuleEx;

public class AdminModule {
	
	public static void main(String[] args) {
		try {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/citiustech/SpringAssignment2/bean.xml");
		AdminOperationsDao adminDao = context.getBean("adminDao",AdminOperationsDao.class);
		boolean isValid = LoginModuleEx.isValid();
		if(isValid) {
			Scanner input=new Scanner(System.in);
			
			boolean exit = false;
			do {
				System.out.println(
						"1.Add Product\n2.Delete Product\n3.Update Product Price\n4.Update Product Name\n5.Update Product Description\n6.Display Product by ID\n7.Display All Products\n0.Exit");
				System.out.println("Enter your choice");
				int choice = input.nextInt();
				switch (choice) {
				case 1:
					Products product=new Products();
					System.out.println("Enter the productId");
					int productId=input.nextInt();
					System.out.println("Enter the product name");
					String productName=input.next();
					System.out.println("Enter the product price");
					float productPrice = input.nextFloat();
					System.out.println("Enter the product description");
					String productDescription=input.next();
					product.setProductId(productId);
					product.setProductName(productName);
					product.setProductDescription(productDescription);
					product.setProductPrice(productPrice);
					adminDao.addProduct(product);
					break;
				case 2:
					Products productTobeDeleted=new Products();
					System.out.println("Enter the productId");
					int productIdForDeletion=input.nextInt();
					productTobeDeleted.setProductId(productIdForDeletion);
					adminDao.deleteProduct(productTobeDeleted);
					break;
				case 3:
					//updateProductPrice();
					Products productPriceTobeUpdated=new Products();
					System.out.println("Enter the productId");
					int productIdForProductPriceUpdation=input.nextInt();
					System.out.println("Enter the product price");
					float updatedProductPrice = input.nextFloat();
					
					productPriceTobeUpdated.setProductId(productIdForProductPriceUpdation);
					productPriceTobeUpdated.setProductPrice(updatedProductPrice);
					adminDao.updateProductPrice(productPriceTobeUpdated);
					
					break;
				case 4:
					//updateProductName();
					Products productNameTobeUpdated=new Products();
					System.out.println("Enter the productId");
					int productIdForProductNameUpdation=input.nextInt();
					System.out.println("Enter the product price");
					String updatedProductName = input.next();
					
					productNameTobeUpdated.setProductId(productIdForProductNameUpdation);
					productNameTobeUpdated.setProductName(updatedProductName);
					adminDao.updateProductName(productNameTobeUpdated);
					break;
				case 5:
					//updateProductDescription();
					Products productDescriptionTobeUpdated=new Products();
					System.out.println("Enter the productId");
					int productIdForProductDescriptionUpdation=input.nextInt();
					System.out.println("Enter the product description");
					String updatedProductDescription = input.next();
					
					productDescriptionTobeUpdated.setProductId(productIdForProductDescriptionUpdation);
					productDescriptionTobeUpdated.setProductDescription(updatedProductDescription);
					adminDao.updateProductDescription(productDescriptionTobeUpdated);
					break;
				case 6:
					//displayProductById();
					Products productTobeDisplayed=new Products();
					System.out.println("Enter the productId");
					int productIdForDisplay=input.nextInt();
					productTobeDisplayed.setProductId(productIdForDisplay);
					adminDao.displayProductById(productTobeDisplayed);
					break;
				case 7:
					//displayAllProducts();
					adminDao.displayAllProducts();
					break;
				case 0:
					exit = true;
					break;
				}
			} while (exit != true);
		
			
			
			
		}else {
			System.out.println("Invalid admin credentials");
		}
		System.out.println("Thank you for using our application");
		}catch(InputMismatchException ex) {
			System.out.println("Kindly enter the number from the given number list!!!!Please try again");
		}
	}
}
