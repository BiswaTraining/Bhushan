package com.citiustech.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.citiustech.model.Products;

public class RowMapperImpl implements RowMapper<Products> {

	public Products mapRow(ResultSet rs, int rowNum) throws SQLException {
		Products prod = new Products();
		prod.setProductId(rs.getInt(1));
		prod.setProductName(rs.getString(2));
		prod.setProductPrice(rs.getFloat(3));
		prod.setProductDescription(rs.getString(4));
		return prod;
	}

}
