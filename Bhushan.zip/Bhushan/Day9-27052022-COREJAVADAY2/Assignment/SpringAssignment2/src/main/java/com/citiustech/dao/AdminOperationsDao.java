package com.citiustech.dao;

import java.util.List;

import com.citiustech.model.Products;

public abstract class AdminOperationsDao {
	public abstract void addProduct(Products product);
	public abstract void deleteProduct(Products product);
	public abstract void updateProductPrice(Products product);
	public abstract void updateProductName(Products product);
	public abstract void updateProductDescription(Products product);
	public abstract Products displayProductById(Products product);
	public abstract List<Products> displayAllProducts();
	
}
