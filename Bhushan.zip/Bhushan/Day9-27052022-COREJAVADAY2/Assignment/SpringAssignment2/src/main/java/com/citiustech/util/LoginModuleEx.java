package com.citiustech.util;

import java.util.Scanner;

public class LoginModuleEx {
	
	public static boolean isValid() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the admin username");
		String adminUsername = input.next();
		System.out.println("Enter the admin password");
		String password = input.next();
		if(adminUsername.equals("admin1") && password.equals("password1")) {
			return true;
		}
		return false;
	}
}
