package com.citiustech.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.citiustech.model.Products;

public class AdminOperationsDaoImpl extends AdminOperationsDao{
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void addProduct(Products product) {
		String query= "insert into product values(?,?,?,?)";
		int rows = this.jdbcTemplate.update(query, product.getProductId(),product.getProductName(),product.getProductPrice(),product.getProductDescription());		
	}

	@Override
	public void deleteProduct(Products product) {
		String query="delete from product where productId=?";
		int rows=this.jdbcTemplate.update(query, product.getProductId());
		
	}

	@Override
	public void updateProductPrice(Products product) {
		String query="update product set productPrice=? where productId=?";
		int rows=this.jdbcTemplate.update(query,product.getProductPrice(),product.getProductId());
		
	}

	@Override
	public void updateProductName(Products product) {
		String query="update product set productName=? where productId=?";
		int rows=this.jdbcTemplate.update(query,product.getProductName(),product.getProductId());
	}

	@Override
	public void updateProductDescription(Products product) {
		String query="update product set productDescription=? where productId=?";
		int rows=this.jdbcTemplate.update(query,product.getProductDescription(),product.getProductId());
		
	}

	@Override
	public Products displayProductById(Products product) {
		String query = "select * from product where productId=?";
		RowMapper<Products> rowMapper = new RowMapperImpl();	
		Products productById =this.jdbcTemplate.queryForObject(query, rowMapper,product.getProductId());
		System.out.println(productById.getProductId()+"  "+productById.getProductName()+"  "+productById.getProductPrice()+"  "+productById.getProductDescription());
		return productById;
	}

	@Override
	public List<Products> displayAllProducts() {
		String query = "select * from product";
		RowMapper<Products> rowMapper = new RowMapperImpl();	
		List<Products> listOfProduts =this.jdbcTemplate.query(query, rowMapper);
		for(Products product:listOfProduts){
			System.out.println(product.getProductId()+"  "+product.getProductName()+"  "+product.getProductPrice()+"  "+product.getProductDescription());
		}
		return listOfProduts;
		
	}

}
