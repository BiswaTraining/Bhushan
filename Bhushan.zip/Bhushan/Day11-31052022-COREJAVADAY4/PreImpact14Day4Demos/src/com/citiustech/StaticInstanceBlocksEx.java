package com.citiustech;

public class StaticInstanceBlocksEx {
	static float PI;
	int emp_id;
	static{
		PI=3.14f;
	}
	{
		emp_id=20;
	}
	public static void main(String[] args) {
		StaticInstanceBlocksEx obj = new StaticInstanceBlocksEx();
		float radius=4;
		System.out.println(PI*radius*radius);
		System.out.println(obj.emp_id);
		
	}

}
