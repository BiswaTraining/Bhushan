package com.citiustech;

public class WrapperEx {

	public static void main(String[] args) {
		
		Integer eid=20;
		
//		Boxing
		int id=10;
		Integer newIdObject = Integer.valueOf(id);
		
		//AutoBoxing  -- Integer.valueOf(id) created internally automatically
		Integer autoBoxedObject = id;
		
		System.out.println(id+"-"+newIdObject+"-"+autoBoxedObject);
		
		//UnBoxing
		Integer score=50;
		int newPrimitiveScore= score.intValue();
		//score.intValue(); created automatically internally
		int newPrimitive=score;
		System.out.println(score+"--"+newPrimitiveScore+"--"+newPrimitive);
		
		int i=10;
		float f=10.5f;
		double d= 34566d;
		
		//AutoBoxing
		Integer ii=i;
		Float ff=f;
		Double dd=d;
		//unBoxing
		int ni = ii;
		float nf=ff;
		double nd=dd;
		
		

	}

}
