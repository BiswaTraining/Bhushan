package com.citiustech;

public class GenericEx {
	public static void main(String[] args) {
		MyType<Integer> obj = new MyType<Integer>(29);
		System.out.println(obj.getObject());
//		MyType obj2 = new MyType("Bhushan");
//		System.out.println(obj2.getObject());
		MyType<String> obj2 = new MyType<String>("Bhushan");
		System.out.println(obj2.getObject());
		
	}

}
class MyType<T>{
	T obj;
	MyType(T obj){
		this.obj=obj;
	}
	public T getObject() {
		return this.obj;
	}
	
}
//class MyClass2{
//	String obj;
//	MyClass2(String obj){
//		this.obj=obj;
//	}
//	public String getObject() {
//		return this.obj;
//	}
//}