package com.citiustech;

public class MutableStringEx {

	public static void main(String[] args) {
//		StringBuffer
//		StringBuilder
		StringBuilder employeeName= new StringBuilder("Bhushan");
		System.out.println(employeeName);
		employeeName.append(" Kumar");
		System.out.println(employeeName);
		employeeName.insert(8, "P");
		System.out.println(employeeName);
		employeeName.delete(8, 9);
		System.out.println(employeeName);
		employeeName.reverse();
		System.out.println(employeeName);
		
		

	}

}
