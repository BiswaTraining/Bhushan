package com.citiustech;

public class StringEx {

	public static void main(String[] args) {
		// String class methods 
//		String first_name="Bhushan";
//		String last_name="Kumar";
//		System.out.println(first_name+last_name);
//		System.out.println(first_name+10+20);
//		System.out.println(10+20+"Bhushan");
//		System.out.println(first_name+100/20);
//		System.out.println(first_name.concat(last_name));
//		//BhushanKumar
//		//Bhushan-Kumar
//		System.out.println(String.join("+", first_name,last_name));
//		
//		String message= "Welcome to Citiustech";
//		//subSequence(int beginIndex, int EndIndex)
//		System.out.println(message.subSequence(8, 10));
//		
//		System.out.println(message.substring(1));
//		System.out.println(message.substring(11,21)); 
		
		//iphone12
		//IPHONE12
		String name="Bhushan          ";
		String name1="bhushan";
		System.out.println(name==name1);
		System.out.println(name.equals(name1));
		System.out.println(name.equalsIgnoreCase(name1));
		System.out.println(name.length());
		System.out.println(name.trim().length());
		System.out.println(name.toUpperCase());
		System.out.println(name.toLowerCase());
		
		
		String myString=null;
		String myString2=" ";
		System.out.println(myString2.isBlank());
		System.out.println(myString2.isEmpty());
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
