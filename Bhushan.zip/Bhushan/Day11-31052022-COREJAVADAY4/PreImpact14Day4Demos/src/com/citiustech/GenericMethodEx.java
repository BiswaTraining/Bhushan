package com.citiustech;

public class GenericMethodEx {

	public static void main(String[] args) {
		myGenericMethod(12);
		myGenericMethod("Bhushan");
		
		

	}
	
	static<T> void myGenericMethod(T element) {
		System.out.println(element);
		System.out.println(element.getClass().getName());
	}

}
