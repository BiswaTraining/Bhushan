package com.citiustech.test;

import com.citiustech.AccessModifierEx;

public class AccessDemo3 extends AccessModifierEx {
	public void getAllNumbers() {
		System.out.println(number1);
//		System.out.println(number2);
		System.out.println(number3);
//		System.out.println(number4);	
		
	}

}
