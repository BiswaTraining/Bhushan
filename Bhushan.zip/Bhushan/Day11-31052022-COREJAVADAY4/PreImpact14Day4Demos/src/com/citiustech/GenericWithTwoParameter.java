package com.citiustech;

public class GenericWithTwoParameter {

	public static void main(String[] args) {
		Test<Integer,String> test = new Test<Integer,String>(12,"Bhushan");
		test.print();

	}

}

class Test<T,E>{
	T obj;
	E obj1;
	Test(T obj,E obj1){
		this.obj=obj;
		this.obj1=obj1;
	}
	public void print() {
		System.out.println(obj);
		System.out.println(obj1);
	}
	
}
