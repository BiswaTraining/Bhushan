package com.citiustech;

import java.util.ArrayList;

public class MyClass {

	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("Bhushan");
		//list.add(1234);
		
//		Object o1,o2,o3,o4;
//		o1="Bhushan";
//		o2=123456;
//		o3='B';
//		o4=56.5f;
		
//		Class1 obj = new Class1();
//		obj.printNumber(10);
//		obj.printNumber(34.5d);
//		obj.printNumber(45.5f);

	}

}
class Class1{
	
	public void printNumber(Object number) {
		System.out.println(number);
	}
//	public void printNumber(double number) {
//		System.out.println(number);
//	}
//	public void printNumber(float number) {
//		System.out.println(number);
//	}
	
}
