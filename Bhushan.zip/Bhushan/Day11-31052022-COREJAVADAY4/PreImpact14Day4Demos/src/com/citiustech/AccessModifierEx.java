package com.citiustech;

public class AccessModifierEx {
	
	public int number1=10;
	private int number2=20;
	protected int number3=30;
	int number4=40;
	public void getAllNumbers() {
		System.out.println(number1);
		System.out.println(number2);
		System.out.println(number3);
		System.out.println(number4);	
	}
}
class AccessDemo1{
	AccessModifierEx obj = new AccessModifierEx();
	public void getAllNumbers() {
		System.out.println(obj.number1);
//		System.out.println(obj.number2);
		System.out.println(obj.number3);
		System.out.println(obj.number4);	
	}
}