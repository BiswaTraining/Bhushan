package com.citiustech.model;

import java.util.List;
import java.util.Scanner;

import com.citiustech.dao.CustomerDatabaseDaoImpl;

public class LoginModuleEx {
	public static boolean validate(String role) {
		Scanner input = new Scanner(System.in);
		boolean isValid=false;
		CustomerDatabaseDaoImpl listOfCustomers = new CustomerDatabaseDaoImpl();
		if (role.equalsIgnoreCase("admin")) {
			List<Customer> adminList = listOfCustomers.getAllCustomerByRole(role);
			System.out.println("Please enter the username");
			String adminName = input.next();
			System.out.println("Please enter the password");
			String adminPass = input.next();
			if(!adminList.isEmpty()){
			for (Customer admin:adminList) {
				if (admin.getCustomer_name().equals(adminName) && admin.getCustomer_password().equals(adminPass)) {
					isValid=true;
					return true;
				}
			}
			}
			if(!isValid) {
				System.out.println("-------------Wrong credentials----------");
				return false;
			}
		}
		
		if (role.equalsIgnoreCase("customer")) {
			List<Customer> customerList = listOfCustomers.getAllCustomerByRole(role);
			System.out.println("Please enter the username");
			String custName = input.next();
			System.out.println("Please enter the password");
			String custPass = input.next();
			if(!customerList.isEmpty()){
			for (Customer customer:customerList) {
				if (customer.getCustomer_name().equals(custName) && customer.getCustomer_password().equals(custPass)) {
					isValid=true;
					return true;
				}
			}
			}
			if(!isValid) {
				System.out.println("-------------Wrong credentials----------");
				return false;
			}
		}
		
		return false;
	}
}
