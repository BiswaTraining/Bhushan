package com.citiustech.dao;

import java.util.List;

import com.citiustech.model.Customer;

public abstract class CustomerDatabaseDao {
	public abstract List<Customer> getAllCustomerByRole(String role);
	public abstract void addCustomers();
	public abstract void updateCustomers();
	public abstract void deleteCustomers();
	public abstract Customer getCustomerById();
	public abstract List<Customer> getAllCustomers();
	
}
