package com.citiustech.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citiustech.model.Customer;
import com.citiustech.model.Product;

public class ProductsFromDatabaseImpl extends ProductsFromDatabase {
	static Connection con = null;
	static Scanner input = new Scanner(System.in);

	@Override
	public List<Product> getProducts() {
		List<Product> productList = new ArrayList<Product>();
		try {
			con = DriverManager.getConnection(
					"jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");
			PreparedStatement pstmt = con.prepareStatement("select * from Product");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setProductPrice(rs.getDouble(3));
				System.out.println(product.getProductId()+" "+product.getProductName()+" "+product.getProductPrice()+" "+product.getProductType());
				productList.add(product);
			}
			pstmt.close();
			con.close();
			return productList;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("SQL exception occured while trying to fetch product details.Please try again later!!!");
		}
		return productList;
	}


	@Override
	public List<Product> getProductDetails(int product_type) {
		List<Product> productList = new ArrayList<Product>();
		try {
			con = DriverManager.getConnection(
					"jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");
			PreparedStatement pstmt = con.prepareStatement("select * from Product where product_type=?");
			pstmt.setInt(1, product_type);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setProductPrice(rs.getDouble(3));
				productList.add(product);
			}
			pstmt.close();
			con.close();
			return productList;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("SQL exception occured while trying to fetch product details.Please try again later!!!");
		}
		return productList;
	}

	@Override
	public void addProducts() {
		try {
			con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
			PreparedStatement pstmt = con.prepareStatement("insert into Product values(?,?,?,?)");
			System.out.println("Enter the ID for Product");
			int pid=input.nextInt();
			System.out.println("Enter the Name of Product");
			String pname=input.next();
			System.out.println("Enter the Price for Product");
			double pprice=input.nextDouble();
			System.out.println("Enter the Type for Product");
			int type=input.nextInt();
			pstmt.setInt(1, pid);
			pstmt.setString(2, pname);
			pstmt.setDouble(3, pprice);
			pstmt.setInt(4, type);
			int row =pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("SQL error occured while adding products");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateProduct() {
		try {
		con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
		PreparedStatement pstmt = con.prepareStatement("update Product set product_name=?,product_price=?,product_type=? where product_id=?");
		System.out.println("Enter the Id for Product");
		int id=input.nextInt();
		System.out.println("Enter the ProductName");
		String pname=input.next();
		System.out.println("Enter the Price of the Product");
		double pprice=input.nextDouble();
		System.out.println("Enter the Type of Product");
		int type=input.nextInt();
		
		pstmt.setString(1, pname);
		pstmt.setDouble(2, pprice);
		pstmt.setInt(3, type);
		pstmt.setInt(4, id);
		int row =pstmt.executeUpdate();
		pstmt.close();
		con.close();
		}catch(SQLException e){
			System.out.println("SQL error occured while updating products");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public void deleteProducts() {
		try {
		con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
		PreparedStatement pstmt = con.prepareStatement("delete from Product where product_id=?");
		System.out.println("Enter the Id for Product");
		int id=input.nextInt();
		pstmt.setInt(1, id);
		int row =pstmt.executeUpdate();
		pstmt.close();
		con.close();
		}catch(SQLException e){
			System.out.println("SQL error occured while deleting products");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

	@Override
	public Product getProductById() {
		Product product = new Product();
		try {
		con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
		PreparedStatement pstmt = con.prepareStatement("select * from Product where product_id=?");
		System.out.println("Enter the Id for Product");
		int id=input.nextInt();
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			product.setProductId(rs.getInt(1));
			product.setProductName(rs.getString(2));
			product.setProductPrice(rs.getDouble(3));
			product.setProductType(rs.getInt(4));
			System.out.println(product.getProductId()+" "+product.getProductName()+" "+product.getProductPrice()+" "+product.getProductType());
		}
		pstmt.close();
		con.close();
		}catch(SQLException e){
			System.out.println("SQL error occured while deleting products");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return product;
	}
}
