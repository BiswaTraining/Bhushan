package com.citiustech.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citiustech.model.Customer;
import com.citiustech.model.Product;

public class CustomerDatabaseDaoImpl extends CustomerDatabaseDao{
	static Connection con = null;
	static Scanner input = new Scanner(System.in);
	
	
	@Override
	public List<Customer> getAllCustomerByRole(String role) {
		List<Customer> customerList = new ArrayList<Customer>();
		try {
			con = DriverManager.getConnection(
					"jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");
			PreparedStatement pstmt = con.prepareStatement("select * from Customer where customer_role=?");
			pstmt.setString(1, role);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomer_id(rs.getInt(1));
				customer.setCustomer_name(rs.getString(2));
				customer.setCustomer_password(rs.getString(3));
				customer.setRole(rs.getString(4));
				customerList.add(customer);
			}
			pstmt.close();
			con.close();
			return customerList;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("SQL exception occured while trying to fetch Customer details.Please try again later!!!");
		}
		return customerList;

	}


	@Override
	public void addCustomers() {
		try {
			con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
			PreparedStatement pstmt = con.prepareStatement("insert into Customer values(?,?,?,?)");
			System.out.println("Enter the ID for Customer");
			int pid=input.nextInt();
			System.out.println("Enter the UserName of Customer");
			String uname=input.next();
			System.out.println("Enter the Password of Customer");
			String password=input.next();
			System.out.println("Enter the Role of the Customer");
			String role=input.next();
			pstmt.setInt(1, pid);
			pstmt.setString(2, uname);
			pstmt.setString(3, password);
			pstmt.setString(4, role);
			int row =pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("SQL error occured while adding customers");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}


	@Override
	public void updateCustomers() {
		try {
			con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
			PreparedStatement pstmt = con.prepareStatement("update Customer set customer_username=?,customer_password=?,customer_role=? where customer_id=?");
			System.out.println("Enter the Id for Customer");
			int id=input.nextInt();
			System.out.println("Enter the User Name");
			String username=input.next();
			System.out.println("Enter the Password");
			String password=input.next();
			System.out.println("Enter the Role");
			String role=input.next();
			
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.setString(3, role);
			pstmt.setInt(4, id);
			int row =pstmt.executeUpdate();
			pstmt.close();
			con.close();
			}catch(SQLException e){
				System.out.println("SQL error occured while updating customers");
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	}


	@Override
	public void deleteCustomers() {
		try {
			con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
			PreparedStatement pstmt = con.prepareStatement("delete from Customer where customer_id=?");
			System.out.println("Enter the Id for Product");
			int id=input.nextInt();
			pstmt.setInt(1, id);
			int row =pstmt.executeUpdate();
			pstmt.close();
			con.close();
			}catch(SQLException e){
				System.out.println("SQL error occured while deleting customer");
				System.out.println(e.getMessage());
				e.printStackTrace();
			}		
	}


	@Override
	public Customer getCustomerById() {
		Customer customer = new Customer();
		try {
		con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");	
		PreparedStatement pstmt = con.prepareStatement("select * from Customer where customer_id=?");
		System.out.println("Enter the Id for Customer");
		int id=input.nextInt();
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			customer.setCustomer_id(rs.getInt(1));
			customer.setCustomer_name(rs.getString(2));
			customer.setCustomer_password(rs.getString(3));
			customer.setRole(rs.getString(4));
			System.out.println("Customer_Id "+" Customer_Username "+" Customer_password "+" Customer_Role");
			System.out.println(customer.getCustomer_id()+" "+customer.getCustomer_name()+" "+customer.getCustomer_password()+" "+customer.getRole());
		}
		pstmt.close();
		con.close();
		}catch(SQLException e){
			System.out.println("SQL error occured while deleting products");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return customer;
	}


	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> customerList = new ArrayList<Customer>();
		try {
			con = DriverManager.getConnection(
					"jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");
			PreparedStatement pstmt = con.prepareStatement("select * from Customer");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomer_id(rs.getInt(1));
				customer.setCustomer_name(rs.getString(2));
				customer.setCustomer_password(rs.getString(3));
				customer.setRole(rs.getString(4));
				System.out.println(customer.getCustomer_id()+" "+customer.getCustomer_name()+" "+customer.getCustomer_password()+" "+customer.getRole());
				customerList.add(customer);
			}
			pstmt.close();
			con.close();
			return customerList;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("SQL exception occured while trying to fetch product details.Please try again later!!!");
		}
		return customerList;
	}

}
