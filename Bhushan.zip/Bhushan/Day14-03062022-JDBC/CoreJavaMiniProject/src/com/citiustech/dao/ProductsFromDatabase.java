package com.citiustech.dao;

import java.util.List;

import com.citiustech.model.Product;

public abstract class ProductsFromDatabase {
	public abstract List<Product> getProducts();
	public abstract List<Product> getProductDetails (int product_type);
	public abstract void addProducts();
	public abstract void updateProduct();
	public abstract void deleteProducts();
	public abstract Product getProductById();

}
