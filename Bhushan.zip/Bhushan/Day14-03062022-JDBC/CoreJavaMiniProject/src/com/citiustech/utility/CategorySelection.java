package com.citiustech.utility;

import java.util.List;
import java.util.Scanner;

import com.citiustech.dao.ProductsFromDatabaseImpl;
import com.citiustech.model.Laptop;
import com.citiustech.model.Product;

public class CategorySelection {

	public static int selectCategory() {
		//Here we have taken selected category's arbitrary number for initialization
		int selectedCategory = 100;
		do {
			System.out.println("------Select Category---------");
			System.out.println("1. Laptop\n2. Phones\n3. Furniture\n4. Fashion\n5. Home Appliances\n0. Exit");
			Scanner categoryInput = new Scanner(System.in);
			selectedCategory = categoryInput.nextInt();
			if (selectedCategory == 0) {
				System.out.println("Thank you for shopping with us!!!Have a great day.");
			}
			if (selectedCategory != 0) {
				selectedCategory = getProductDetails(selectedCategory);
			}
		} while (selectedCategory != 0);
		return 0;
	}

	//// Method to get the product details
	public static int getProductDetails(int category) {
		boolean loopProductDetails = false;
		do {
			Scanner categoryInput = new Scanner(System.in);
			ProductsFromDatabaseImpl laptops = new ProductsFromDatabaseImpl();
			List<Product> productDetailslist = laptops.getProductDetails(category);
			if (productDetailslist != null && !productDetailslist.isEmpty()) {
				System.out.println("Please select a product");
				for (Product product : productDetailslist) {
					System.out.println(
							product.getProductId() + ". " + product.getProductName() + " " + product.getProductPrice());
				}
				System.out.println("0.Exit");
				int productId = categoryInput.nextInt();
				if (productId == 0) {
					loopProductDetails = false;
				} else {
					boolean isProductIdMatched = false;
					double productPrice = 0.0;
					String productName = null;
					for (Product listOfProducts : productDetailslist) {
						if (listOfProducts.getProductId() == productId) {
							isProductIdMatched = true;
							productPrice = listOfProducts.getProductPrice();
							productName = listOfProducts.getProductName();
						}
					}
					if (!isProductIdMatched) {
						System.out.println("Please select the product id mentioned in the list");
						loopProductDetails=false;
					} else {
						System.out.println("Enter the number of Products required");
						double numberOfProducts = categoryInput.nextDouble();
						double totalPrice = productPrice * numberOfProducts;
						System.out.println("Name of the product = " + productName);
						System.out.println("Quantity = " + numberOfProducts);
						System.out.println("Your Bill = " + totalPrice);
						System.out.println("Thank you for your purchase.");
						System.out.println("Do you want to Continue?");
						System.out.println("Please type YES to continue or NO to go back to the previous menu");
						String continueFlag = categoryInput.next();
						if (continueFlag != null && !continueFlag.isBlank() && !continueFlag.isEmpty()
								&& continueFlag.equalsIgnoreCase("YES")) {
							loopProductDetails = true;
						} else if (continueFlag != null && !continueFlag.isBlank() && !continueFlag.isEmpty()
								&& continueFlag.equalsIgnoreCase("NO")) {
							loopProductDetails = true;
						}
					}
				}
			} else {
				System.out.println("Product out of stock");
			}
		} while (loopProductDetails != false);
		return 1;
	}
}