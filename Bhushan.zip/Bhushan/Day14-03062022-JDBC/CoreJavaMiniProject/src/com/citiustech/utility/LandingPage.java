package com.citiustech.utility;

import java.util.Scanner;

public class LandingPage {
	public static int getMenu() {
		boolean exitFlag = false;
		int menu;
		Scanner input = new Scanner(System.in);
		do {
			System.out.println("Please select the role from the menu");
			System.out.println("--------Menu--------\n1.Admin\n2.Customer\n3.Exit");
			menu = input.nextInt();
			if (menu == 1 || menu == 2 || menu == 3) {
				exitFlag = true;
			}
		} while (exitFlag != true);
		return menu;
	}
}
