package com.citiustech.utility;

import java.util.Scanner;

import com.citiustech.dao.CustomerDatabaseDaoImpl;
import com.citiustech.dao.ProductsFromDatabaseImpl;

public class AdminService {

	public static void adminTasks() {
		Scanner input = new Scanner(System.in);
		boolean exit = false;
		do {
			System.out.println("  ");
			System.out.println("Please enter the choice");
			System.out.println(
					"1. Add Product\n2. Update Product\n3. Delete Product\n4. Get Product by ID\n5. Get All Products\n6. Add customer\n7. Update Customer Information\n8. Delete Customer\n9. Get Customer by ID\n10. Get All Customer\n0. Exit");
			int choice = input.nextInt();
			switch (choice) {
			case 1:
				addProducts();
				break;
			case 2:
				updateProducts();
				break;
			case 3:
				deleteProducts();
				break;
			case 4:
				getProductsById();
				break;
			case 5:
				getAllProducts();
				break;
			case 6:
				addCustomer();
				break;
			case 7:
				updateCustomer();
				break;
			case 8:
				deleteCustomers();
				break;
			case 9:
				getCustomersById();
				break;
			case 10:
				getAllCustomers();
				break;
			case 0:
				exit = true;
				break;

			}
		} while (exit != true);
	}

	public static void addProducts() {
		ProductsFromDatabaseImpl addProducts = new ProductsFromDatabaseImpl();
		addProducts.addProducts();
	}

	public static void addCustomer() {
		CustomerDatabaseDaoImpl addCustomers = new CustomerDatabaseDaoImpl();
		addCustomers.addCustomers();
	}

	public static void updateProducts() {
		ProductsFromDatabaseImpl updateProducts = new ProductsFromDatabaseImpl();
		updateProducts.updateProduct();
	}

	public static void updateCustomer() {
		CustomerDatabaseDaoImpl updateCustomers = new CustomerDatabaseDaoImpl();
		updateCustomers.updateCustomers();
	}

	public static void deleteProducts() {
		ProductsFromDatabaseImpl deleteProducts = new ProductsFromDatabaseImpl();
		deleteProducts.deleteProducts();
	}

	public static void deleteCustomers() {
		CustomerDatabaseDaoImpl deleteCustomers = new CustomerDatabaseDaoImpl();
		deleteCustomers.deleteCustomers();
	}

	public static void getProductsById() {
		ProductsFromDatabaseImpl getProductsById = new ProductsFromDatabaseImpl();
		getProductsById.getProductById();
	}

	public static void getCustomersById() {
		CustomerDatabaseDaoImpl getCustomersById = new CustomerDatabaseDaoImpl();
		getCustomersById.getCustomerById();
	}

	public static void getAllProducts() {
		ProductsFromDatabaseImpl getAllProducts = new ProductsFromDatabaseImpl();
		getAllProducts.getProducts();
	}

	public static void getAllCustomers() {
		CustomerDatabaseDaoImpl getAllCustomers = new CustomerDatabaseDaoImpl();
		getAllCustomers.getAllCustomers();
	}
}
