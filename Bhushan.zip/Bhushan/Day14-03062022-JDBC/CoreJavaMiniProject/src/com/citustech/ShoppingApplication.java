package com.citustech;

import com.citiustech.model.LoginModuleEx;
import com.citiustech.utility.AdminService;
import com.citiustech.utility.CategorySelection;
import com.citiustech.utility.LandingPage;

import java.util.InputMismatchException;

public class ShoppingApplication {

	public static void main(String[] args) {
		try {
			boolean exit=false;
			do {			
			int menu = LandingPage.getMenu();
			
			switch (menu) {
			case 1:
				System.out.println("-------------Admin module------------------");
				boolean isAdminValidated = LoginModuleEx.validate("admin");
				if (isAdminValidated) {
					AdminService.adminTasks();
				}
				break;
			case 2:
				int category = 2;
				System.out.println("-------------Customer module---------------");
				boolean isCustomerValidated = LoginModuleEx.validate("customer");
				if (isCustomerValidated) {
					System.out.println("Congratulations!!!Customer validation successful");
					do {
						category = CategorySelection.selectCategory();
					} while (category != 0);
				}
				break;
			case 3:
				exit=true;
				System.out
						.println("-------------Bye!!!! Thank you for shopping with us.Have a great day---------------");
			}
		} while(exit!=true);
		}catch (InputMismatchException inputException) {
			System.out.println(
					"OOPS!!!!!!! Please enter a number from the menu.Thank you for shooping with us.Please try again");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			System.out.println("OOPS!!!! Something went wrong.Please try again later");
		}
	}
}
