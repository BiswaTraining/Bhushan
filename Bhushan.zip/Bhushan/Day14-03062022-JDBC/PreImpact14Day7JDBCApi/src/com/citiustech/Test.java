package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {

	public static void main(String[] args) throws ClassNotFoundException {
		//step 1
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
		//step 2
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=master;user=sa;password=password_123");
		//step 3
			Statement stmt = con.createStatement();
		
		//step 4 Execute Query
			stmt.executeUpdate("insert into testTable values(4,'Pencil')");
			System.out.println("Product Added in database");
			
		//Step 5
			con.close();
			
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
