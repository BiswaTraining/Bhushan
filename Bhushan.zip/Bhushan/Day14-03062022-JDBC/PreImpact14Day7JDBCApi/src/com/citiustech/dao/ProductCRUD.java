package com.citiustech.dao;

import java.util.List;

import com.citiustech.model.Product;

public interface ProductCRUD {
	public int insertProduct();
	public int updateProduct();
	public int deleteProduct();
	public List<Product>getProduct();
	public List<Product> getProductById();

}
