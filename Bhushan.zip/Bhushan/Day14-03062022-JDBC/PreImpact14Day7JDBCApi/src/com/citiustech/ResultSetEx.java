package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSetEx {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery("select * from ProductDetails");
			rs.next();
			System.out.println(rs.getInt("product_id")+"--"+rs.getString(2)+"--"+rs.getFloat(3));
			rs.absolute(4);
			System.out.println(rs.getInt("product_id")+"--"+rs.getString(2)+"--"+rs.getFloat(3));
			rs.previous();
			System.out.println(rs.getInt("product_id")+"--"+rs.getString(2)+"--"+rs.getFloat(3));
			stmt.close();
			con.close();	
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

}
