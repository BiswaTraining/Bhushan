package com.citiustech;

import com.citiustech.dao.ProductCRUDImpl;

public class SoppingApplication {

	public static void main(String[] args) {
		System.out.println("Admin");
		System.out.println("1. Add Product");
		System.out.println("Enter your choice");
		int choice=1;
		if(choice==1) {
			ProductCRUDImpl obj = new ProductCRUDImpl();
			int row = obj.insertProduct();
			System.out.println(row+" Afftected");
		}

	}

}
