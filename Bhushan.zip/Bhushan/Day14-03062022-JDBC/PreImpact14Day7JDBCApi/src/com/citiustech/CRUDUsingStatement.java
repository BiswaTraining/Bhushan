package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CRUDUsingStatement {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
			Statement stmt = con.createStatement();
			
			int pid=24;
			String pname="Cup";
			float pprice=45.5f;
			
			//inserting data in table
			//step 4 execture query
			int row =stmt.executeUpdate("insert into ProductDetails values(10,'Sofa', 25000)");
//			System.out.println(row+" rows affected");
			
			//update data in table
//			int row =stmt.executeUpdate("update ProductDetails set product_name='Wall Clock' where product_id=10");
//			System.out.println(row+" rows affected");
			
			//delete row
//			int row =stmt.executeUpdate("delete from ProductDetails where product_id=10");
//			System.out.println(row+" rows affected");
			
			//Display
			ResultSet rs =  stmt.executeQuery("select * from ProductDetails");
			while(rs.next()) {
				System.out.println(rs.getInt("product_id")+"--"+rs.getString(2)+"--"+rs.getFloat(3));
			}
			stmt.close();
			con.close();	
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

}
