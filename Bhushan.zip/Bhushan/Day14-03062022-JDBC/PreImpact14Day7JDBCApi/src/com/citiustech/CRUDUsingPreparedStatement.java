package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CRUDUsingPreparedStatement {
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
		
		//insert into 
//		PreparedStatement pstmt = con.prepareStatement("insert into ProductDetails values(?,?,?)");
//		System.out.println("Enter the ID for Product");
//		int pid=input.nextInt();
//		System.out.println("Enter the Name of Product");
//		String pname=input.next();
//		System.out.println("Enter the Price for Product");
//		float pprice=input.nextFloat();
//		pstmt.setInt(1, pid);
//		pstmt.setString(2, pname);
//		pstmt.setFloat(3, pprice);
//		int row =pstmt.executeUpdate();
//		System.out.println(row+" row/s afftected");
		


		
		//delete 
//		PreparedStatement pstmt = con.prepareStatement("delete from ProductDetails where product_id=?");
//		System.out.println("Enter the ID for Product");
//		int pid=input.nextInt();
//		pstmt.setInt(1, pid);
//		int row =pstmt.executeUpdate();
//		System.out.println(row+" row/s afftected");
		
		//Fetch data using where clause
		PreparedStatement pstmt = con.prepareStatement("select * from ProductDetails where product_id=?");
		System.out.println("Enter the ID for Product");
		int pid=input.nextInt();
		pstmt.setInt(1, pid);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt("product_id")+"--"+rs.getString(2)+"--"+rs.getFloat(3));
		}
		pstmt.close();
		con.close();
		
		
		}catch(SQLException ex) {
			System.out.println(ex.getMessage());
			
		}
		

	}

}
