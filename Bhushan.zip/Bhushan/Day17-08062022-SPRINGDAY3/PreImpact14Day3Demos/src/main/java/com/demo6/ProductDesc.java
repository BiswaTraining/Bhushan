package com.demo6;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class ProductDesc {
	@Value("Apple")
	private String productBrand;
	@Value("Awesome Quality")
	private String productQuality;
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductQuality() {
		return productQuality;
	}
	public void setProductQuality(String productQuality) {
		this.productQuality = productQuality;
	}
	@Override
	public String toString() {
		return "ProductDesc [productBrand=" + productBrand + ", productQuality=" + productQuality + "]";
	}
	
	

}
