package com.demo4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo4/bean.xml");
		Student std = context.getBean("student" , Student.class);
		System.out.println(std);
		
		LoginService service= context.getBean("ser", LoginService.class);
		boolean isValid =service.isValidUser();
		System.out.println("IS Valid USer "+isValid);
	}

}
