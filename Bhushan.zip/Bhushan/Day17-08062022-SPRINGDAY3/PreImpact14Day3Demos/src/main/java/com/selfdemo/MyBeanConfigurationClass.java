package com.selfdemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.selfdemo")
public class MyBeanConfigurationClass {

}
