package com.demo5;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeRepo implements EmpRepo<Employee> {

	private Map<Integer,Employee> repository;
	
	public EmployeeRepo() {
		this.repository= new HashMap<Integer,Employee>();
	}
	
	public void insert(Employee t) {
		repository.put(t.getEmpId(), t);
		
	}

	public Employee getEmployeeById(int empId) {
		
		return repository.get(empId);
	}

	public Employee deleteEmployee(int empId) {
		
		return repository.remove(empId);
	}

}
