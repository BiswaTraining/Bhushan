package com.demo6;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainCalss {

	public static void main(String[] args) {
		ApplicationContext context = new 
				AnnotationConfigApplicationContext(JavaConfigurationClass.class);
		Product product = context.getBean("product",Product.class);
		System.out.println(product.getProduct_id());
		System.out.println(product.getProduct_name());
		System.out.println(product.getProduct_price());
		System.out.println(product.getProductDesc().getProductBrand());
		System.out.println(product.getProductDesc().getProductQuality());
		

	}

}
