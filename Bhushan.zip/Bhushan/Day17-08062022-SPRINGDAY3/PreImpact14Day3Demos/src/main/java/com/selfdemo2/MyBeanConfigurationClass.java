package com.selfdemo2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBeanConfigurationClass {
	@Bean
	public Employee getEmployee() {
		Employee employee=new Employee();
		employee.setAddress(getAddress());
		return employee;
	}
	@Bean
	public Address getAddress() {
		Address address =new Address();
		return address;
	}
}
