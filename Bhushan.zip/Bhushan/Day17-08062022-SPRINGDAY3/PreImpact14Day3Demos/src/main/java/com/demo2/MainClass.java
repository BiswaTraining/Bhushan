package com.demo2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo2/bean.xml");
		Emp emp = context.getBean("emp", Emp.class);
		System.out.println(emp);
		
		
		Emp emp2 = context.getBean("emp", Emp.class);
		
		System.out.println(emp.hashCode());
		System.out.println(emp2.hashCode());

	}

}
