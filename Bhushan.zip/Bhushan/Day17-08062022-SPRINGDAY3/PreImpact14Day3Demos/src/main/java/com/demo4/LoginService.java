package com.demo4;


import org.springframework.stereotype.Service;

@Service("ser")
public class LoginService {
	
	public boolean isValidUser() {
		if("admin".equals("admin"))
			return true;
		else
			return false;
	}

}
