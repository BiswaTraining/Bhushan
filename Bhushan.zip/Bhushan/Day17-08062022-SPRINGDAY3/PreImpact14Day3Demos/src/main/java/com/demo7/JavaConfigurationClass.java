package com.demo7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(basePackages = "com.demo7")
public class JavaConfigurationClass {
	
	@Bean
	public Product getProduct() {
		Product product = new Product();
		product.setProductDesc(getDesc());
		return product;
	}
	
	@Bean
	public ProductDesc getDesc() {
		ProductDesc desc = new ProductDesc();
		return desc;
	}

}
