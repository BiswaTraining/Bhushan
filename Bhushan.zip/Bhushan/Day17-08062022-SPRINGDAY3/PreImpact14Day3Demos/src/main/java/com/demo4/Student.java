package com.demo4;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {
	@Value("James")
	private String student_name;
	@Value("Mumbai")
	private String student_Address;
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getStudent_Address() {
		return student_Address;
	}
	public void setStudent_Address(String student_Address) {
		this.student_Address = student_Address;
	}
	@Override
	public String toString() {
		return "Student [student_name=" + student_name + ", student_Address=" + student_Address + "]";
	}
	
}
