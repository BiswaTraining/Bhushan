package com.demo5;

public interface EmpRepo<T> {

	public void insert(T t);
	
	public T getEmployeeById(int empId);
	
	public T deleteEmployee(int empId);
	
	
}
