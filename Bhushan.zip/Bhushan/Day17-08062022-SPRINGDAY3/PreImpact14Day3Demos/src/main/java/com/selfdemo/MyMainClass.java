package com.selfdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MyMainClass {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(MyBeanConfigurationClass.class);
		Employee emp = context.getBean("emp",Employee.class);
		System.out.println(emp);
	}
}
