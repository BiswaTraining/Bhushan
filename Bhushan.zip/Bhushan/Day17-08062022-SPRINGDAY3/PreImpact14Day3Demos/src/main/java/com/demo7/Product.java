package com.demo7;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component
public class Product {
	@Value("101")
	private int product_id;
	@Value("Iphone 13")
	private String product_name;
	@Value("85000.50")
	private float product_price;
	@Autowired
	private ProductDesc productDesc;
	
	public ProductDesc getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(ProductDesc productDesc) {
		this.productDesc = productDesc;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public float getProduct_price() {
		return product_price;
	}
	public void setProduct_price(float product_price) {
		this.product_price = product_price;
	}
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name=" + product_name + ", product_price="
				+ product_price + ", productDesc=" + productDesc + "]";
	}
	
	

}
