package com.demo5;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.context.ApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo5/bean.xml");
		EmployeeRepo empRepo = context.getBean(EmployeeRepo.class);
		//Self tried below
//		EmployeeRepo empRepo = context.getBean("employeeRepo",EmployeeRepo.class);
		empRepo.insert(new Employee(1,"John"));
		empRepo.insert(new Employee(2,"Simon"));
		System.out.println("Employees Added");
		
		Employee emp = empRepo.getEmployeeById(1);
		System.out.println(emp);
		
		Employee deletedEmployee= empRepo.deleteEmployee(2);
		System.out.println(" Deleted Employee ="+deletedEmployee);
	}

}
