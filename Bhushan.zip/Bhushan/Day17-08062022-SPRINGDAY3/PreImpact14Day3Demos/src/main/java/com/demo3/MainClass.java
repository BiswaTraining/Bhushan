package com.demo3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo3/bean.xml");
		 Employee emp = context.getBean("emp",Employee.class);
		 System.out.println(emp);
		 
		 Employee emp2 = context.getBean("emp",Employee.class);
		 System.out.println(emp.hashCode());
		 System.out.println(emp2.hashCode());
	}
}

// Employee 
// Employee employee = new Employee();