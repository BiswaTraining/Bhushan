package com.demo1;

public class Address {
	private String landMark;
	private String city;
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [landMark=" + landMark + ", city=" + city + "]";
	}
	public Address(String landMark, String city) {
		this.landMark = landMark;
		this.city = city;
	}
	public Address() {
		
	}
	

}
