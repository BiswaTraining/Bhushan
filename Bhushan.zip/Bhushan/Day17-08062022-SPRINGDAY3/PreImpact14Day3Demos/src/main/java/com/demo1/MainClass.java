package com.demo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo1/bean.xml");
		Emp emp = context.getBean("emp", Emp.class);
		System.out.println(emp);	
		System.out.println(emp.getAddress());
		Emp emp1 = context.getBean("emp", Emp.class);
		System.out.println(emp1.getAddress());

		System.out.println(emp.hashCode());
		System.out.println(emp1.hashCode());
	
	}

}
