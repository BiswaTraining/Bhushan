package com.Impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.connection.RowMapperCustomerImpl;
import com.connection.RowMapperCustomerValidImpl;
import com.dao.UsersDAO;
import com.model.Users;

public class UserDAOImpl implements UsersDAO {

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean validateUser(String username, String password) {

		String query = null;
		boolean validate = false;
		Users users = null;

		query = "select TOP 1 user_id from user_details where username = ? and password = ?";

		users = this.jdbcTemplate.queryForObject(query, new RowMapperCustomerValidImpl(), username, password);

		if (users != null) {

			if (users.getUserId() != 0) {

				validate = true;

				return validate;

			}

		}

		return validate;
	}

	public int addUser(Users users) {

		String query = "insert into user_details values (?,?,?,?)";

		int row = this.jdbcTemplate.update(query, users.getUsername(), users.getPassword(), users.getName(),
				users.getMobileNo());

		return row;

	}

	public int updateUser(Users users) {

		String query = "update user_details set name = ?, mobile_number = ? where user_id = ? ";

		int row = this.jdbcTemplate.update(query, users.getName(), users.getMobileNo(), users.getUserId());

		return row;

	}

	public int deleteUser(Users users) {

		String query = "delete from user_details where user_id = ? ";

		int row = this.jdbcTemplate.update(query, users.getUserId());

		return row;

	}

	public Users getUserById(Users users) {

		Users user = null;

		String query = "select * from user_details where user_id = ?";

		user = (Users) this.jdbcTemplate.queryForObject(query, new RowMapperCustomerImpl(), users.getUserId());

		return user;

	}

	public List<Users> getAllUsers() {

		List<Users> users = null;

		String query = "select * from user_details";

		users = (List<Users>) this.jdbcTemplate.query(query, new RowMapperCustomerImpl());

		return users;

	}

}
