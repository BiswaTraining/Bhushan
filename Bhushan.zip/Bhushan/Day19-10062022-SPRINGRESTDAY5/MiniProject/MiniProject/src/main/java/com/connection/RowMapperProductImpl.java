package com.connection;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Products;

public class RowMapperProductImpl implements RowMapper<Products> {

	public Products mapRow(ResultSet rs, int rowNum) throws SQLException {

		Products product = new Products();

		product.setProduct_id(rs.getInt(1));
		product.setCategory_id(rs.getInt(2));
		product.setProduct_name(rs.getString(3));
		product.setProduct_price(rs.getInt(4));

		return product;
	}

}
