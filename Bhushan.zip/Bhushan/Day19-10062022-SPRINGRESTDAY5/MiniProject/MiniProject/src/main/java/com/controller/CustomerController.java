package com.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Impl.ProductDaoImpl;
import com.Impl.UserDAOImpl;
import com.connection.JavaConfiguration;
import com.model.Products;

@Controller
public class CustomerController {

	static ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfiguration.class);
	static UserDAOImpl userDAOImpl = context.getBean("userDAOImpl", UserDAOImpl.class);
	static ProductDaoImpl productDaoImpl = context.getBean("productDaoImpl", ProductDaoImpl.class);

	@RequestMapping("/selected_category")
	public ModelAndView selectedCateory(@RequestParam("category") int categoryId) {
		ModelAndView mv = new ModelAndView();
		List<Products> productList = productDaoImpl.getProductListByCategoryId(categoryId);
		mv.addObject("products", productList);
		mv.setViewName("cart");
		return mv;

	}

	@PostMapping("/place_order")
	public ModelAndView updateProduct(@RequestParam int product_id, @RequestParam int quantity) {
		ModelAndView mv = new ModelAndView();
		Products product = new Products();
		product.setProduct_id(product_id);
		product = productDaoImpl.getProductById(product);
		float bill = (float) (product.getProduct_price() * quantity);
		productDaoImpl.saveOrderDetails(product, 0, quantity, bill);
		mv.addObject("product", product);
		mv.addObject("quantity", quantity);
		mv.addObject("bill_amount", bill);
		mv.setViewName("orderSummary");
		return mv;
	}

}
