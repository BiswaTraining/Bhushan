package com.connection;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Admins;

public class RowMapperAdminImpl implements RowMapper<Admins> {

	public Admins mapRow(ResultSet rs, int rowNum) throws SQLException {

		Admins admins = new Admins();

		admins.setUserId(rs.getInt(1));

		return admins;
	}

}
