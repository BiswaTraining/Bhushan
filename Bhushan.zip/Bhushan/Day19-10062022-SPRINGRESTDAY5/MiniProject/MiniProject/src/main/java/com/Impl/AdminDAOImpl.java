package com.Impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.connection.RowMapperAdminImpl;
import com.dao.AdminsDAO;
import com.model.Admins;

public class AdminDAOImpl implements AdminsDAO {

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	// *****

	public boolean validateAdmin(String username, String password) {

		String query = null;
		boolean validate = false;
		Admins admins = null;

		query = "select TOP 1 admin_id from admin_details where username = ? and password = ?";

		admins = this.jdbcTemplate.queryForObject(query, new RowMapperAdminImpl(), username, password);

		if (admins != null) {

			if (admins.getUserId() != 0) {

				validate = true;

				return validate;

			}

		}

		return validate;
	}

}
