package com.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Impl.ProductDaoImpl;
import com.Impl.UserDAOImpl;
import com.connection.JavaConfiguration;
import com.model.Category;
import com.model.Products;
import com.model.Users;

@Controller
public class AdminController {

	static ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfiguration.class);
	static ProductDaoImpl productDaoImpl = context.getBean("productDaoImpl", ProductDaoImpl.class);
	static UserDAOImpl userDAOImpl = context.getBean("userDAOImpl", UserDAOImpl.class);

	@RequestMapping("/admin")
	public String adminMenu() {

		return "admin";

	}

	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {

		ModelAndView mv = new ModelAndView();
		List<Category> categoryId_list = productDaoImpl.getCategoryId();
		mv.addObject("listCategory", categoryId_list);
		mv.setViewName("addProduct");
		return mv;

	}

	@RequestMapping("/product_added")
	public String insertProduct(@ModelAttribute Products product, @RequestParam("category") int categoryId) {
		product.setCategory_id(categoryId);
		productDaoImpl.addProduct(product);
		return "product_added";

	}

	@RequestMapping("/editProduct")
	public String editProduct() {

		return "updateProduct";

	}

	@RequestMapping("/product_updated")
	public String updateProduct(@ModelAttribute Products product) {
		productDaoImpl.updateProduct(product);
		return "product_updated";

	}

	@RequestMapping("/removeProduct")
	public String removeProduct() {

		return "deleteProduct";

	}

	@RequestMapping("/product_deleted")
	public String deleteProduct(@ModelAttribute Products product) {
		productDaoImpl.updateProduct(product);
		return "product_deleted";

	}

	@RequestMapping("/getSingleProduct")
	public String getProductById() {

		return "getProductById";

	}

	@RequestMapping("/displayProduct")
	public ModelAndView displayProduct(@ModelAttribute Products products) {

		ModelAndView mv = new ModelAndView();

		Products product = productDaoImpl.getProductById(products);

		mv.addObject("product", product);
		mv.setViewName("displayProduct");

		return mv;

	}

	@RequestMapping("/getAllProducts")
	public ModelAndView getAllProducts() {

		ModelAndView mv = new ModelAndView();
		List<Products> productList = productDaoImpl.getAllProducts();
		mv.addObject("products", productList);
		mv.setViewName("displayAllProducts");
		return mv;

	}

	// ********************************************

	@RequestMapping("/addCustomer")
	public String addCustomer() {

		return "addCustomer";

	}

	@RequestMapping("/customer_added")
	public String insert(@ModelAttribute Users users) {
		userDAOImpl.addUser(users);
		return "customer_added";

	}

	@RequestMapping("/editCustomer")
	public String editCustomer() {

		return "updateCustomer";

	}

	@RequestMapping("/customer_updated")
	public String updateCustomer(@ModelAttribute Users users) {
		userDAOImpl.updateUser(users);
		return "customer_updated";

	}

	@RequestMapping("/removeCustomer")
	public String removeCustomer() {

		return "deleteCustomer";

	}

	@RequestMapping("/customer_deleted")
	public String deleteCustomer(@ModelAttribute Users users) {
		userDAOImpl.deleteUser(users);
		return "customer_deleted";

	}

	@RequestMapping("/getSingleCustomer")
	public String getCustomerById() {
		return "getCustomerById";

	}

	@RequestMapping("/displayCustomer")
	public ModelAndView displayCustomer(@ModelAttribute Users users) {
		ModelAndView mv = new ModelAndView();
		Users user = userDAOImpl.getUserById(users);
		mv.addObject("user", user);
		mv.setViewName("displayCustomer");
		return mv;

	}

	@RequestMapping("/getAllCustomers")
	public ModelAndView getAllCustomers() {
		ModelAndView mv = new ModelAndView();
		List<Users> userList = userDAOImpl.getAllUsers();
		mv.addObject("users", userList);
		mv.setViewName("displayAllCustomers");
		return mv;

	}

}
