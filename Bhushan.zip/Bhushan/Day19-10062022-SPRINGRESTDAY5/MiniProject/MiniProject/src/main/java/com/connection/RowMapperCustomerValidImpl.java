package com.connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.model.Users;

public class RowMapperCustomerValidImpl implements RowMapper<Users> {

	public Users mapRow(ResultSet rs, int rowNum) throws SQLException {

		Users users = new Users();

		users.setUserId(rs.getInt(1));

		return users;
	}

}
