package com.Impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.connection.RowMapperCategoryImpl;
import com.connection.RowMapperProductImpl;
import com.dao.ProductsDAO;
import com.model.Category;
import com.model.Products;

public class ProductDaoImpl implements ProductsDAO {

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Category> getCategoryId() {

		List<Category> categoryId_list = null;

		String query = "select * from category_details";

		categoryId_list = this.jdbcTemplate.query(query, new RowMapperCategoryImpl());

		return categoryId_list;
	}

	public int addProduct(Products product) {

		String query = "insert into product_details values (?,?,?)";

		int row = this.jdbcTemplate.update(query, product.getCategory_id(), product.getProduct_name(),
				product.getProduct_price());

		return row;

	}

	public int updateProduct(Products product) {

		String query = "update product_details set product_name = ?, product_price = ? where product_id = ? ";

		int row = this.jdbcTemplate.update(query, product.getProduct_name(), product.getProduct_price(),
				product.getProduct_id());

		return row;

	}

	public int deleteProduct(Products product) {

		String query = "delete from product_details where product_id = ? ";

		int row = this.jdbcTemplate.update(query, product.getProduct_id());

		return row;

	}

	public Products getProductById(Products product) {

		Products products = null;

		String query = "select * from product_details where product_id = ?";

		products = (Products) this.jdbcTemplate.queryForObject(query, new RowMapperProductImpl(),
				product.getProduct_id());

		return products;

	}

	public List<Products> getAllProducts() {

		List<Products> products = null;

		String query = "select * from product_details";

		products = (List<Products>) this.jdbcTemplate.query(query, new RowMapperProductImpl());

		return products;

	}

	public List<Products> getProductListByCategoryId(int category_id) {

		List<Products> products = null;

		String query = "select * from product_details where category_id = ?";

		products = (List<Products>) this.jdbcTemplate.query(query, new RowMapperProductImpl(), category_id);

		return products;

	}

	public int saveOrderDetails(Products product, int user_id, int quantity, float bill) {

		String query = "insert into order_details values(?,?,?,?,?)";

		int rows = jdbcTemplate.update(query, user_id, product.getProduct_id(), product.getProduct_name(), quantity,
				bill);

		return rows;
	}

}
