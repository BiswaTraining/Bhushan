package com.dao;

import java.util.List;

import com.model.Category;
import com.model.Products;

public interface ProductsDAO {

	public int addProduct(Products product);

	public int updateProduct(Products product);

	public int deleteProduct(Products product);

	public Products getProductById(Products product);

	public List<Products> getAllProducts();

	public List<Category> getCategoryId();

	public List<Products> getProductListByCategoryId(int category_id);

	public int saveOrderDetails(Products product, int user_id, int quantity, float bill);

}
