package com.connection;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.Impl.AdminDAOImpl;
import com.Impl.ProductDaoImpl;
import com.Impl.UserDAOImpl;

@Configuration
public class JavaConfiguration {

	@Bean(name = { "ds" })
	public DriverManagerDataSource getDataSource() {

		DriverManagerDataSource ds = new DriverManagerDataSource();

		ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		ds.setUrl("jdbc:sqlserver://localhost;databaseName=shoppingAppDb;instanceName=SQLEXPRESS");
		ds.setUsername("sa");
		ds.setPassword("password_123");

		return ds;

	}

	@Bean(name = { "jdbcTemp" })
	public JdbcTemplate getTemplate() {

		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(getDataSource());
		return jdbcTemplate;

	}

	@Bean(name = { "adminDAOImpl" })
	public AdminDAOImpl getAdminDao() {

		AdminDAOImpl adminDAOImpl = new AdminDAOImpl();
		adminDAOImpl.setJdbcTemplate(getTemplate());
		return adminDAOImpl;

	}

	@Bean(name = { "productDaoImpl" })
	public ProductDaoImpl getProductDao() {
		ProductDaoImpl productDaoImpl = new ProductDaoImpl();
		productDaoImpl.setJdbcTemplate(getTemplate());
		return productDaoImpl;

	}

	@Bean(name = { "userDAOImpl" })
	public UserDAOImpl getUserDao() {
		UserDAOImpl userDAOImpl = new UserDAOImpl();
		userDAOImpl.setJdbcTemplate(getTemplate());
		return userDAOImpl;

	}

}
