package com.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Impl.AdminDAOImpl;
import com.Impl.ProductDaoImpl;
import com.Impl.UserDAOImpl;
import com.connection.JavaConfiguration;
import com.model.Category;

@Controller
public class LoginController {

	static ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfiguration.class);
	static AdminDAOImpl adminDAOImpl = context.getBean("adminDAOImpl", AdminDAOImpl.class);
	static UserDAOImpl userDAOImpl = context.getBean("userDAOImpl", UserDAOImpl.class);
	static ProductDaoImpl productDaoImpl = context.getBean("productDaoImpl", ProductDaoImpl.class);

	@RequestMapping("/login")
	public String getHome() {
		return "login";
	}

	@RequestMapping("/authenticate")
	public ModelAndView authenticate(@RequestParam("username") String username,
			@RequestParam("password") String password, @RequestParam("user_type") String user_type) {

		ModelAndView mv = new ModelAndView();
		boolean isValid = false;

		if (user_type.equals("a")) {

			isValid = adminDAOImpl.validateAdmin(username, password);

			if (isValid) {

				mv.setViewName("admin");
				return mv;

			}

			mv.setViewName("loginError");
			return mv;

		} else if (user_type.equals("b")) {

			isValid = userDAOImpl.validateUser(username, password);

			if (isValid) {

				List<Category> categoryId_list = productDaoImpl.getCategoryId();
				mv.addObject("listCategory", categoryId_list);
				mv.setViewName("customer");
				return mv;

			}

			mv.setViewName("loginError");
			return mv;

		} else {

			System.out.println("Invalid Choice");
			mv.setViewName("loginError");
			return mv;
		}

	}

}
