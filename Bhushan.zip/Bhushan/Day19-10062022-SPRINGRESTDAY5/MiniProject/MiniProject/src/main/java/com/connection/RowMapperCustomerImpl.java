package com.connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.model.Users;

public class RowMapperCustomerImpl implements RowMapper<Users> {

	public Users mapRow(ResultSet rs, int rowNum) throws SQLException {

		Users users = new Users();

		users.setUserId(rs.getInt(1));
		users.setUsername(rs.getString(2));
		users.setPassword(rs.getString(3));
		users.setName(rs.getString(4));
		users.setMobileNo(rs.getString(5));

		return users;
	}

}
