package com.model;

public class Users {

	private int userId;
	private String username;
	private String password;
	private String name;
	private String mobileNo;

	public Users(int userId, String username, String password, String name, String mobileNo) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.name = name;
		this.mobileNo = mobileNo;
	}

	public Users() {
		// TODO Auto-generated constructor stub
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "username=" + username + ", password=" + password + ", name=" + name + ", mobileNo=" + mobileNo;
	}

}
