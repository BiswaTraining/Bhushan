package com.model;

public class Products {

	private int product_id;
	private int category_id;
	private String product_name;
	private int product_price;

	public Products(int product_id, String product_name, int product_price, int category_id) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.category_id = category_id;
	}

	public Products() {
		super();
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	@Override
	public String toString() {
		return "Id =" + product_id + ", Category Id=" + category_id + ", Name=" + product_name + ", Price="
				+ product_price;
	}

}
