package com.dao;

import java.util.List;

import com.model.Users;

public interface UsersDAO {

	public boolean validateUser(String username, String password);

	public int addUser(Users users);

	public int updateUser(Users users);

	public int deleteUser(Users users);

	public Users getUserById(Users users);

	public List<Users> getAllUsers();

}
