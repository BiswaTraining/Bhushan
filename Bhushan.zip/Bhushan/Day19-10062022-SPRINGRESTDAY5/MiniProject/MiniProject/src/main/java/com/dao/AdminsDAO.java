package com.dao;

public interface AdminsDAO {

	public boolean validateAdmin(String username, String password);

}
