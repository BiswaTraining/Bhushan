package com.rest;

public class StudentNotFountException extends RuntimeException{
	StudentNotFountException(String message){
		super(message);
	}
}
