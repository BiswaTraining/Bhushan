package com.rest;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.model.Student;
import com.model.StudentErrorResponse;

@RestController
@EnableWebMvc
@RequestMapping("/api")
public class StudentController {
	static List<Student> list;
	
//	@ExceptionHandler
//	public ResponseEntity<StudentErrorResponse> handleException(StudentNotFountException ex){
//		StudentErrorResponse error = new StudentErrorResponse();
//		error.setStatus_code(HttpStatus.NOT_FOUND.value());
//		error.setMessage(ex.getMessage());
//		error.setTimestramp(System.currentTimeMillis());
//		return new ResponseEntity(error, HttpStatus.NOT_FOUND);
//	}
//	
//	@ExceptionHandler
//	public ResponseEntity<StudentErrorResponse> handleException(Exception ex){
//		StudentErrorResponse error = new StudentErrorResponse();
//		error.setStatus_code(HttpStatus.BAD_REQUEST.value());
//		error.setMessage(ex.getMessage());
//		error.setTimestramp(System.currentTimeMillis());
//		return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
//	}
//	
	
	
	@PostConstruct
	public void loadData() {
		list= new ArrayList();
		list.add(new Student("John","Conor"));
		list.add(new Student("Kim","Lin"));
		list.add(new Student("Eric","Conor"));
		list.add(new Student("Tom","Thomson"));	
	}
	
	//url for get => http://localhost:8080/RESTDemo2/api/students
	@GetMapping("/students")
	public List<Student> getStudent(){
		return list;
	}

	
	//url for get only one object => http://localhost:8080/RESTDemo2/api/students/stid
	@GetMapping("/students/{stid}")
	public Student getStudent(@PathVariable int stid) {
		return list.get(stid);
		
	}
	
	@PostMapping("/student")
	public Student addStudent(@RequestBody Student student){
		list.add(student);
		return student;
	}
		
	@DeleteMapping("/student/{stid}")
	public void deleteStudent(@PathVariable int stid) {
		list.remove(stid);
//		return student;
	}
	
	@PutMapping("/student/{stid}")
	public void updateStudent(@PathVariable int stid) {
		Student student = list.get(stid);
		student.setFname("Vimal");
		student.setLname("Kumar");
		
	}
	
}
