package com.model;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MainClass {

	public static void main(String[] args) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			Student student = 
					mapper.readValue(new File("Data/Studdent-info.json"),Student.class);
			System.out.println("ID ="+student.getId());
			System.out.println("First Name="+student.getFirst_name());
			System.out.println("Last Name="+student.getLast_name());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} 

	}

}
