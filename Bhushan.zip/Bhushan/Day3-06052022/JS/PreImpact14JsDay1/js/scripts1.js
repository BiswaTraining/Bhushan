// alert("Hi");
//-------------------------Session 2
//Looping constructs
//let employee=['John','James','Simon','Timo','Jason','Tom'];
// console.log(employee);

//for loop
// for(let i=0;i<employee.length;i++){
//     console.log("Employee Name ="+employee[i]);
// }


//for in loop
// for(let emp in employee){
// console.log("Printing data uisng For in");
// console.log("Employee Name= "+employee[emp]);
// }

//---while loop
// let j=0;
// while(j<employee.length){
//     console.log("Employee Name ="+employee[j]);
//     j++;
// }


//----------do While loop
// let k=0;
// do{
//     console.log(employee[k]);
//     k++;
// }while(k<employee.length)

// let nameOfStudent="Bhushan";


//------------------------------------Strict mode
// 'use strict'
// let hasLic=false;
// let passDrivingTest= true;
// if(passDrivingTest)hasLic=true;
// if(hasLic)console.log("I can drive");


//--------------------------Function------------

//declared function
// function getGreet(){
// console.log("Good Morning");
// console.log("Had Breakfast?");
// console.log("Have lunch please");
// console.log("Good Afternnon");
// }
// getGreet();

//scenaio for function
//I want to create a function which will make fruit juice;
// example of function with parameters
// function makingJuice(apples,oranges){
// let message=`Juice is ready with ${apples} apples and ${oranges} oranges`;
// return message;
// }
// console.log(makingJuice(4,8))


//function as an Expression
// const studentInfo= function(studName){
//     return `Student's Name =${studName}`;
// }
// const stName= studentInfo("Zanillia");
// console.log(stName);



//calling function from other Function

//function 1
// function makingJuice(apples ,oranges){
//     const applePieces= cutFruitInPieces(apples);
//     const orangesPieces = cutFruitInPieces(oranges);
//     let message=`Juice is Ready ${applePieces} apple pieces and ${orangesPieces} oranges pieces `;
//     return message;
// }

// //function 2
// function cutFruitInPieces(fruit){
//     return fruit*4;
// }


// console.log(makingJuice(2,4));




//Arraow function Example 1 for single line function
const carInfo = carName => `Car Name =${carName}`;
let cn = carInfo("Harrier");
console.log(cn);

//multiple line function
//My function will be accepting two parameters
//1. NameOfEmloyee and 2. YearOfBirth
// My function will calculate year left for retirement

const yearLeftForRetirement= (yearOfBirth, nameOfEmployee)=>{
    const currentAge= 2022-yearOfBirth;
    const yearLeft = 60-currentAge;
    return `${nameOfEmployee} is going to retire in ${yearLeft} years`;
}

console.log(yearLeftForRetirement(1990,"John"));





