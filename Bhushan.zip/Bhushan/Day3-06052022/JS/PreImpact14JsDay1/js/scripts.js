
//------------------------------Session 1-----------------------------------------

//------------------------------Basic Understanding
// alert("Welcome to Citiustech");
// let message="Good Morning";
// alert(message+" "+"Welcome To Citiustech");
// console.log("Hello");

//---------------------------Values and Variables
//let new ="Bhushan";
// let firstName="Bhushan";
// let PI=3.14;
// //let 1StudentName="James";
// // let student&Name="Bhushan";
// console.log("Student's Name ="+firstName);

//------------------------Data Types
// we can use let, const, var for declaring variables
//broadly we can say there are some standard types in JS
//Number -- All the numbers will be comes under this data type
// let marksOfEnglish=89;
//String -- String values
// let nameOfStudent="John";
//boolean -- for true and false
// let result=true;

//undefined
// let age;

// console.log(typeof marksOfEnglish);
// console.log(typeof nameOfStudent);
// console.log(typeof result);
// console.log(typeof age);

//-------------------let,const , var
//let - use to declare variable whose value can be changed later
// let firstName;
// firstName="Bhushan";
// console.log(firstName);
// firstName=12345;
// console.log(firstName);

//const -- If we don't want to change value later we can use const
// const myCountry="India";
// console.log(myCountry);
//not possible
// myCountry="China";
// console.log(myCountry);

//var
// var address="Mumbai";
// console.log(address);
// address="Delhi";
// console.log(address);

//---------------------------Operators
//calculator to calculate age of a person
//--------------------------Arithmetic OPerators
// const currentYear=2022;
// const ageOFBhushan= currentYear-1980;
// console.log(ageOFBhushan);
// //area of circle
// let areaOfCircle=3.14*4*4;
// console.log(areaOfCircle);
//------------------------Assignemnts Operator
// let x=10+5;
// x +=10; //x=x+10;
// x *=4;
// console.log(x);

//-----------------------comparison operator
// let num1=10;
// let num2=20;
// console.log(num1>num2);

//-------------------Solution for Problem statement in PPT
const massofMark=78;
const heightOfMark=1.69;
const massOfJohn=92;
const heightOfJohn=1.95;

const bmiOfMark=massofMark/heightOfMark*2;
console.log(bmiOfMark);
const bmiOfJohn=massOfJohn/heightOfJohn*2;
console.log(bmiOfJohn);

const heigherBMI=bmiOfMark>bmiOfJohn;
console.log(heigherBMI);


//------------------------------String and String Templates
//String manipulation
// let empFirstName="John";
// let empLastName="Coner";
// let empInfo= empFirstName+" is a very good Employee "+empLastName+" is his last name";
// console.log(empInfo);

// //String templates
// let empNewInfo= `${empFirstName} is very good Employee ${empLastName} is his last name`;
// console.log(empNewInfo);

//------------------------------------Conditional Statements
//--if
// const username="Bhushan";
// if(username==="Bhushan")alert("Login Successful")

//if else
//scenario -- Getting driving Lic.
//Age>18
// const age=15;
// if(age>18)
// console.log("You are eligible for Getting Driv. Lic.");
// else{
//     let yearLeftForLic = 18-age;
//     console.log(`You are not eligible , you can try after ${yearLeftForLic} years`);
// }

//else if
// const age=18;
// if(age>18){
//     console.log("You are eligible for Getting Driv. Lic.");
// }
// else if(age==18){
//     console.log("Wait for Three months");
// }
// else{
//     console.log("Not Eligible");
// }


//Type Conversion and coersion
// let yearOfManu ="1992";
// console.log(typeof yearOfManu);
// console.log(Number(yearOfManu));
// console.log(yearOfManu+18); //199218
// console.log(Number(yearOfManu)+18);


// let studentName="John";
// console.log(Number(studentName));

// let percentage=75;
// console.log(typeof percentage);
// console.log(String(percentage));


//----------------------coersion
// console.log("My Name is Bhushan and I am"+18+" Years Old");
// console.log('23'-'10'-"3");
// console.log("46"/"2");
// console.log("bhushan"-"John");


//--------------- == Vs ===

// let username ="Bhushan";
// if(username==="Bhushan")alert("Done");

// let id='18';
// if(id===18)alert("ID is 18");


//--------Logical OPerators
// let vision="bad";
// let age=19;
// if(age>18 || vision=="good"){
//     console.log("Please Go Ahead");
// }
// else{
//     console.log("Stop");
// }


//switch case
// let choice = "mobile";
// switch (choice) {
//     case 'mobile':
//         console.log("You have selected Mobile");
//         break;
//     case 'laptop':
//         console.log("You have selected Laptop");
//         break;
//     default:
//         console.log("Wrong Choice");
// }

//ternary OPerator
// let age=19;
// age>18?console.log("Eligible"):console.log("Not Eligible");


