'use strict'

function calculateSalary(basicSalary){
    let hra=0.08*basicSalary;
    let tda=0.24*basicSalary;
    let medAllowance = 0.3*basicSalary;
    let misc=0.2*basicSalary;
    let monthlySalary=basicSalary+hra+tda+medAllowance+misc;
    let annualIncome=monthlySalary*12;
    console.log(`Your Total Salary per Month= "${monthlySalary}"`);
    console.log(`Total Salary per Anum=”${annualIncome} ” `);
    calculateTax(annualIncome,monthlySalary);
}

function calculateTax(annualIncome,monthlySalary){
    let TotalTax=0;
    if(annualIncome<=500000){
        console.log(`Total Tax = “${TotalTax} ” `);
        console.log(`Monthly Deduction per month = “${TotalTax/12} ”`);
        console.log(`You will get salary per month = “${monthlySalary} ”`);
    }
    if(annualIncome>500000 && annualIncome<=1000000){
        TotalTax=0.1*annualIncome;
        console.log(`Total Tax = “${TotalTax} ” `);
        console.log(`Monthly Deduction per month = “${TotalTax/12} ”`);
        console.log(`You will get salary per month = “${monthlySalary-(TotalTax/12)} ”`);
    }
    if(annualIncome>1000000 && annualIncome<=2000000){
        TotalTax=0.15*annualIncome;
        console.log(`Total Tax = “${TotalTax} ” `);
        console.log(`Monthly Deduction per month = “${TotalTax/12} ”`);
        console.log(`You will get salary per month = “${monthlySalary-(TotalTax/12)} ”`);
    }
    if(annualIncome>2000000){
        TotalTax=0.20*annualIncome;
        console.log(`Total Tax = “${TotalTax} ” `);
        console.log(`Monthly Deduction per month = “${TotalTax/12} ”`);
        console.log(`You will get salary per month = “${monthlySalary-(TotalTax/12)} ”`);
    }
}

calculateSalary(100);