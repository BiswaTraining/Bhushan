package com.demo9;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("com/demo9/bean.xml");
		Product prod =context.getBean("prod", Product.class);
		System.out.println(prod);
		context.close();
//		context.registerShutdownHook();
		

	}

}
