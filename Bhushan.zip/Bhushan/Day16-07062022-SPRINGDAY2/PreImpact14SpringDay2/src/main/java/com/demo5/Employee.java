package com.demo5;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee {
	private String emp_name;
	private List<String> emp_phones;
	private Set<String> address;
	private Map<String, String> techStack;
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public List<String> getEmp_phones() {
		return emp_phones;
	}
	public void setEmp_phones(List<String> emp_phones) {
		this.emp_phones = emp_phones;
	}
	public Set<String> getAddress() {
		return address;
	}
	public void setAddress(Set<String> address) {
		this.address = address;
	}
	public Map<String, String> getTechStack() {
		return techStack;
	}
	public void setTechStack(Map<String, String> techStack) {
		this.techStack = techStack;
	}
	@Override
	public String toString() {
		return "Employee [emp_name=" + emp_name + ", emp_phones=" + emp_phones + ", address=" + address + ", techStack="
				+ techStack + "]";
	}
	
	

}
