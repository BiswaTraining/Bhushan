package com.demo6;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Employee {

	private String emp_name;
	private List<String> project_names;
	private Map<Integer, String> department_name;
	private Properties props;
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public List<String> getProject_names() {
		return project_names;
	}
	public void setProject_names(List<String> project_names) {
		this.project_names = project_names;
	}
	public Map<Integer, String> getDepartment_name() {
		return department_name;
	}
	public void setDepartment_name(Map<Integer, String> department_name) {
		this.department_name = department_name;
	}
	public Properties getProps() {
		return props;
	}
	public void setProps(Properties props) {
		this.props = props;
	}
	@Override
	public String toString() {
		return "Employee [emp_name=" + emp_name + ", project_names=" + project_names + ", department_name="
				+ department_name + ", props=" + props + "]";
	}
	
	
}
