package com.demo2;

public class Student {
	private int studentId;
	private String studentName;
	private String address;
	private int phone;
	private int age;
	public Student(int studentId, String studentName, String address) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.address = address;
	}
	
	public Student(int studentId, String studentName, String address, int phone, int age) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.address = address;
		this.phone = phone;
		this.age = age;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", address=" + address + "]";
	}
	

}	
