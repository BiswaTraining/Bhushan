package com.demo8;
//Implementing life cycle using XML

public class Product {
	private int product_id;

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		System.out.println("Setting value for product_id");
		this.product_id = product_id;
	}

	@Override
	public String toString() {
		return "Product [product_id=" + product_id + "]";
	}
	
	// init() destroy()
	public void myInit() {
		System.out.println("Initialization is in picture.......");
	}

	
	public void myDestroy() {
		System.out.println("Destroying all stuffs...............");
	}
}
