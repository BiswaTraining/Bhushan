package com.demo1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class App {

	public static void main(String[] args) {
		//BeanFactory
		//way 1
//		ClassPathResource resource = new ClassPathResource("com/demo1/bean.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
		
		//way 2
//		BeanFactory factory1 = new XmlBeanFactory(new ClassPathResource("com/demo1/bean.xml"));
//		factory1.getBean("");
		
		//Application Context
		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo1/bean.xml");
		Student st = context.getBean("student1", Student.class);
		System.out.println(st);
		
		
		
	}

}
