package com.demo9;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

//Implementing life cycle using Interfaces
//InitializingBean for init
//DispozableBean for destroy

public class Product implements InitializingBean, DisposableBean{
	private int product_id;

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		System.out.println("Setting value for product_id");
		this.product_id = product_id;
	}

	@Override
	public String toString() {
		return "Product [product_id=" + product_id + "]";
	}

	public void destroy() throws Exception {
		System.out.println("Destroy Method");
		
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("Init Method");
		
	}

}
