package com.demo10;
//Implementing life cycle using XML

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Product {
	private int product_id;

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		System.out.println("Setting value for product_id");
		this.product_id = product_id;
	}

	@Override
	public String toString() {
		return "Product [product_id=" + product_id + "]";
	}
	
	@PostConstruct
	public void start() {
		System.out.println("Initialization is in picture.......");
	}

	@PreDestroy
	public void stop() {
		System.out.println("Destroying all stuffs...............");
	}
}
