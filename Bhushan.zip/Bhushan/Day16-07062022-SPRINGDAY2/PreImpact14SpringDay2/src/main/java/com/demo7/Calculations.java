package com.demo7;

public class Calculations {
	private int a;
	private int b;
	
	public Calculations(double a, double b) {
		this.a=(int)a;
		this.b=(int)b;
		System.out.println("Double type Constructor");
	}
	
	public Calculations(int a, int b) {
		this.a=a;
		this.b=b;
		System.out.println("Int type Constructor");
	}
	
	
	public Calculations(String a, String b) {
		this.a=Integer.parseInt(a);
		this.b=Integer.parseInt(b);
		System.out.println("String type Constructor");
	}
	
	public void addition() {
		System.out.println("A ="+this.a);
		System.out.println("B ="+this.b);
		System.out.println("Addition is "+(this.a+this.b));
	}

}
