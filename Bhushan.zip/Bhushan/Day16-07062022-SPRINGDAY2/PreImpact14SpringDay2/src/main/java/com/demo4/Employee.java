package com.demo4;

public class Employee {
	private int emp_id;
	private String emp_name;
	private String emp_phone;
	private Address address;
	
	
	
	public Employee(int emp_id, String emp_name, String emp_phone, Address address) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_phone = emp_phone;
		this.address = address;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_phone=" + emp_phone + ", address="
				+ address + "]";
	} 
	

}
