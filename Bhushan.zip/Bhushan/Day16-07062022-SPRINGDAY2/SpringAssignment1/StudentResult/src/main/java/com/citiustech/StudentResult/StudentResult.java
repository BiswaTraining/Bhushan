package com.citiustech.StudentResult;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentResult 
{
    public static void main( String[] args )
    {
       ApplicationContext context = new ClassPathXmlApplicationContext("com/citiustech/StudentResult/bean.xml");
       Student stu = context.getBean("student",Student.class);
       stu.checkResult();
    }
}
