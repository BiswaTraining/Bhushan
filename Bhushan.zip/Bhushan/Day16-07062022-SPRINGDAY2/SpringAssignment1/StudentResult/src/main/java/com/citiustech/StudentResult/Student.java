package com.citiustech.StudentResult;

public class Student {
	private String rollNumber;
	private String name;
	private float englishMarks;
	private float historyMarks;
	private float geographyMarks;
	private float matsMarks;
	public String getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getEnglishMarks() {
		return englishMarks;
	}
	public void setEnglishMarks(float englishMarks) {
		this.englishMarks = englishMarks;
	}
	public float getHistoryMarks() {
		return historyMarks;
	}
	public void setHistoryMarks(float historyMarks) {
		this.historyMarks = historyMarks;
	}
	public float getGeographyMarks() {
		return geographyMarks;
	}
	public void setGeographyMarks(float geographyMarks) {
		this.geographyMarks = geographyMarks;
	}
	public float getMatsMarks() {
		return matsMarks;
	}
	public void setMatsMarks(float matsMarks) {
		this.matsMarks = matsMarks;
	}
	public Student(String rollNumber, String name, float englishMarks, float historyMarks, float geographyMarks,
			float matsMarks) {
		super();
		this.rollNumber = rollNumber;
		this.name = name;
		this.englishMarks = englishMarks;
		this.historyMarks = historyMarks;
		this.geographyMarks = geographyMarks;
		this.matsMarks = matsMarks;
	}
	public Student() {
		super();
	}
	
	public void checkResult() {
		String result="Failed";
		float sum =this.englishMarks+this.geographyMarks+this.historyMarks+this.matsMarks;
		float percentage=((sum*100)/400);;
		if(this.englishMarks>=35 && this.geographyMarks>=35 && this.historyMarks>=35 && this.matsMarks>=35 && percentage>60) {
			result="Passed";
		}
		System.out.println("Name of Student = "+this.name);
		System.out.println("Roll number = "+this.rollNumber);
		System.out.println("English Marks = "+this.englishMarks);
		System.out.println("History Marks = "+this.historyMarks);
		System.out.println("Geography Marks = "+this.geographyMarks);
		System.out.println("Maths Marks = "+this.matsMarks);
		System.out.println("Percentage = "+percentage);
		System.out.println("Result = "+result);
	}
	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", name=" + name + ", englishMarks=" + englishMarks
				+ ", historyMarks=" + historyMarks + ", geographyMarks=" + geographyMarks + ", matsMarks=" + matsMarks
				+ "]";
	}
}
