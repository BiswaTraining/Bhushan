package com.citiustech;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyFirstSpringEx {

	public static void main(String[] args) {
		//For loading the config file we need object of Context
		ApplicationContext context = new ClassPathXmlApplicationContext("com/citiustech/bean.xml");
		//Objct1
		MessageClass ms =context.getBean("myMessage",MessageClass.class);
		System.out.println(ms.getMessage());
		//Object 2
		MessageClass ms1 =context.getBean("myMessage2",MessageClass.class);
		System.out.println(ms1.getMessage());
		
		
		

	}

}
