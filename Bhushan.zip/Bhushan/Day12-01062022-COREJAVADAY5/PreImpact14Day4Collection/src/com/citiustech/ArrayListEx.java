package com.citiustech;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListEx {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("John");
		list.add(10);
		list.add(20);
		list.add(null);
		list.add("John");
		System.out.println(list);
		list.add(0, "Bhushan");
		System.out.println(list);
		list.remove(5);
		System.out.println(list);
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Object object = (Object) iterator.next();
			System.out.println(object);
			
		}
	}

}
