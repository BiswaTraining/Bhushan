package com.citiustech;

import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		Vector vector = new Vector();
		System.out.println(vector.capacity());
		for (int i = 0; i < vector.capacity(); i++) {
			vector.add(i);
			
		}
		System.out.println(vector);
		vector.add("Bhushan");
		System.out.println(vector.capacity());

	}

}
