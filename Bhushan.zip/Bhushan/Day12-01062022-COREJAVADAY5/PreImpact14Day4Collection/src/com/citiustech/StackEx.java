package com.citiustech;

import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		Stack stack = new Stack();
		stack.push("John");
		stack.add(0, "James");
		stack.add("Vinod");
		System.out.println(stack);
		System.out.println(stack.search("James"));
		System.out.println(stack.get(2));

	}

}
