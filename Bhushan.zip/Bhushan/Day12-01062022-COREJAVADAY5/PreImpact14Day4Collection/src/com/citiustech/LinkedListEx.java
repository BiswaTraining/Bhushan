package com.citiustech;

import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.add("John");
		list.add("James");
		list.add("Simon");
		list.add(null);
		list.add("John");
		System.out.println(list);
		list.addFirst("Bhushan");
		System.out.println(list);
		list.addLast("Kevin");
		System.out.println(list);
		list.removeFirst();
		list.removeLast();
		System.out.println(list);
		
		

	}

}
