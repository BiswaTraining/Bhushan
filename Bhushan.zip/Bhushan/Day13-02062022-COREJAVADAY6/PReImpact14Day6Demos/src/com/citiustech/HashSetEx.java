package com.citiustech;

import java.util.HashSet;

public class HashSetEx {

	public static void main(String[] args) {
		HashSet set = new HashSet();
		set.add("John");
		set.add("James");
		set.add("Kevin");
		set.add(null);
		System.out.println(set.add("John"));
		System.out.println(set);
	}

}
