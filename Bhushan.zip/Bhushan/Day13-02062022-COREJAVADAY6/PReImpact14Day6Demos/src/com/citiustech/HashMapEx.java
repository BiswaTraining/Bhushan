package com.citiustech;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapEx {

	public static void main(String[] args) {
		HashMap map = new HashMap();
		map.put(101, "John");
		map.put(102, "James");
		map.put(103, "Brian");
		map.put(104, "Zanillia");
		System.out.println(map);
		System.out.println(map.put(103, "Simon"));
		
		Set set = map.keySet();
		System.out.println(set);
		
		Collection collection=map.values();
		System.out.println(collection);
		
		Set entryset = map.entrySet();
		System.out.println(entryset);
		
		Iterator itr = entryset.iterator();
		while(itr.hasNext()) {
			Map.Entry m = (Map.Entry)itr.next();
			System.out.println("Employee ID ="+m.getKey()+" Employee Name="+m.getValue());
			if((Integer)m.getKey()==103) {
				m.setValue("Vinod");
			}
		}
		System.out.println(map);
		
		
		
				
		

	}

}
