package com.citiustech;

import java.util.Comparator;
import java.util.TreeSet;

public class ComparatorEx {

	public static void main(String[] args) {
		TreeSet set = new TreeSet(new MyClasss());
		set.add(10);
		set.add(20); // compare(20,10)
		set.add(0);  // compare(0,10)
		set.add(12); // compare(12,10)  compare(12,20)
		set.add(14); // compare(14,10) compare(14,12) compare(14,20)
		System.out.println(set);

	}

}
class MyClasss implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Integer number1 = (Integer)o1;
		Integer number2 = (Integer)o2;
//		return number1.compareTo(number2);//ascending order
//		return -number1.compareTo(number2);//descending order
//		return number2.compareTo(number1);
//		return -number2.compareTo(number1);
//		return +1;
//		return -1;
		return 0;
//		if(number1<number2)
//			return +1;
//		else if(number1>number2)
//			return -1;
//		else
//			return 0;
	}
	
}