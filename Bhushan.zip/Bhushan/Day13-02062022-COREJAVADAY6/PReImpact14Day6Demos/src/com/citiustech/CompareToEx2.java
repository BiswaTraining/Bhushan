package com.citiustech;

import java.util.Comparator;
import java.util.TreeSet;

public class CompareToEx2 {

	public static void main(String[] args) {
		TreeSet set = new TreeSet(new MyClasss2());
		set.add("Bhushan");
		set.add("Abc");
		set.add("Zanillia");
		set.add("Kim");
		set.add("Linda");
		System.out.println(set);

	}

}
class MyClasss2 implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		String number1 = (String)o1;
		String number2 = (String)o2;
		
//		return number1.compareTo(number2);//ascending order
		return -number1.compareTo(number2);//descending order
//		return number2.compareTo(number1);
//		return -number2.compareTo(number1);
//		return +1;
//		return -1;
//		return 0;
//		if(number1<number2)
//			return +1;
//		else if(number1>number2)
//			return -1;
//		else
//			return 0;
	}
	
}
