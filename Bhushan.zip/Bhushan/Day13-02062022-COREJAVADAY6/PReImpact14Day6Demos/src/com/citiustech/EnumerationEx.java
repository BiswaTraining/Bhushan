package com.citiustech;

import java.util.Enumeration;
import java.util.Vector;

public class EnumerationEx {

	public static void main(String[] args) {
		Vector vector = new Vector();
		for (int i = 0; i < vector.capacity(); i++) {
			vector.add(i);
		}
		System.out.println(vector);
		Enumeration enumeration= vector.elements();
		while(enumeration.hasMoreElements()) {
			Integer number =(Integer)enumeration.nextElement();
			if(number%2==0) {
				System.out.println(number);
			}
			
			
		}

	}

}
