package com.citiustech;

import java.util.LinkedList;
import java.util.ListIterator;

public class ListIteratorEx {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.add("John");
		list.add("James");
		list.add("Kevin");
		list.add("Tom");
		System.out.println(list);
		//we will have to create object of ListITerator
		ListIterator litr = list.listIterator();
		while(litr.hasNext()) {
			String names =(String)litr.next();
			if(names.equals("John")) {
				litr.remove();
			}
			else if(names.equals("Tom")) {
				litr.add("Zanillia");
			}
			else if(names.equals("Kevin")) {
				litr.set("Vinod");
			}
		}
		System.out.println(list);
	}

}
