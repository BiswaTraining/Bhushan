package com.citiustech;

import java.util.Comparator;
import java.util.TreeSet;

public class UserDefineObjectSorting {

	public static void main(String[] args) {
		Poducts p1= new Poducts(10, "Sofa", 15000);
		Poducts p2= new Poducts(101, "Phone", 15000);
		Poducts p3= new Poducts(18, "Laptop", 15000);
		Poducts p4= new Poducts(22, "Pen", 15000);
		Poducts p5= new Poducts(109, "Lock", 15000);
		
		TreeSet set = new TreeSet();
		set.add(p1);
		set.add(p2);
		set.add(p3);
		set.add(p4);
		set.add(p5);
		System.out.println(set);
	}

}
class Poducts implements Comparable{
	int product_id;
	String product_name;
	double product_price;

	public Poducts(int product_id, String product_name, double product_price) {
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
	}
	
	@Override
	public String toString() {
		return "product_id=" + product_id + ", product_name=" + product_name + ", product_price="
				+ product_price + "";
	}

	@Override
	public int compareTo(Object o) {
		int product_id=this.product_id;
		Poducts product =(Poducts)o;
		int productId2=product.product_id;
		if(product_id<productId2)
			return -1;
		else if(product_id>productId2)
			return +1;
		else
			return 0;
		
	}
	
}

class MyComparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Poducts p1= (Poducts)o1;
		Poducts p2= (Poducts)o2;
		
		
		return 0;
	}
	
	
}
