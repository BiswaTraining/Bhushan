package com.citiustech;

import java.util.TreeSet;

public class TreeSetEx {

	public static void main(String[] args) {
		TreeSet set = new TreeSet();
		set.add(null);
//		set.add(new StringBuffer("Z"));
//		set.add(new StringBuffer("T"));
//		set.add(new StringBuffer("L"));
//		set.add(new StringBuffer("B"));
//		set.add(new StringBuffer("A"));
		
//		System.out.println(set);
//		set.add("Z");
//		set.add("H");
//		set.add("G");
//		set.add("a");
//		set.add("A");
//		set.add(null);
//		set.add(1234);
//		set.add(123);
//		set.add(12);
//		set.add(453636);
		System.out.println(set);
		

	}

}
