package com.citiustech;

public class ComparableEx {

	public static void main(String[] args) {
		System.out.println("A".compareTo("Z"));//
		System.out.println("Z".compareTo("K"));
		System.out.println("Z".compareTo("Z"));//0
		System.out.println("Z".compareTo(null)); //NPE
		

	}

}
//A   Z
