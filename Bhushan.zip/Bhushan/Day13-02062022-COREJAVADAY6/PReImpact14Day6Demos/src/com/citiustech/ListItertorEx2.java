package com.citiustech;

import java.util.LinkedList;
import java.util.ListIterator;

public class ListItertorEx2 {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.add("John");
		list.add("James");
		list.add("Kevin");
		list.add("Tom");
//		System.out.println(list);
		ListIterator litr = list.listIterator();
		
		System.out.println(litr.next());
		System.out.println(litr.nextIndex());
		System.out.println(litr.next()); //James
		System.out.println(litr.previous()); //James
		System.out.println(litr.previous());
		System.out.println(litr.next());
		System.out.println(litr.previousIndex());

	}

}
