package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//1. create a folder in your project and paste jar files 
		//2. right clcik on project go to build path
		//3. in libraries click classpath and click on add jars
		

public class TestDb {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
																		//IMCCBCP48-MSL1\SQLEXPRESS
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=TestDb1;user=sa;password=password_123");
			System.out.println("Connected");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

}
