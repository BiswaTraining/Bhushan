package com.citiustech;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class LinkedHashSetEx {

	public static void main(String[] args) {
		LinkedHashSet set = new LinkedHashSet();
		set.add("John");
		set.add("James");
		set.add("Kevin");
		set.add(null);
		System.out.println(set.add("John"));
		System.out.println(set);

	}

}
