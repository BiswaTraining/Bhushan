package com.citiustech.utility;

import java.util.List;
import java.util.Scanner;

import com.citiustech.dao.ProductsFromDatabaseImpl;
import com.citiustech.model.Laptop;
import com.citiustech.model.Product;

public class CategorySelection {

	public static int selectCategory() {
		System.out.println("------Select Category---------");
		System.out.println("1. Laptop\n2. Phones\n3. Furniture\n4. Fashion\n5. Home Appliances0. Exit");
		Scanner categoryInput = new Scanner(System.in);
		int selectedCategory = categoryInput.nextInt();
		ProductsFromDatabaseImpl laptops = new ProductsFromDatabaseImpl();
		List<Product> productDetails = laptops.getProductDetails(selectedCategory);
		if(productDetails!=null) {
			int count=1;
			for(Product product:productDetails) {
				System.out.println(count+". "+product.getProductName()+" "+product.getProductPrice());
				count++;
			}
		}else {
			System.out.println("Product out of stock");
		}
		switch(selectedCategory) {
		case 1:laptops.getProductDetails(selectedCategory);
		case 2:break;
		case 3:break;
		case 4:break;
		case 5:break;
		case 0:break;
		}
		return 1;
	}
	
	public static void getLaptops() {
		Laptop[] laptops=new Laptop[5];
		laptops[0]=new Laptop("Lenovo thinkPad", 55000);
		laptops[1]=new Laptop("Dell Inspiron", 75000);
		laptops[2]=new Laptop("HP Pavilion", 50000);
		laptops[3]=new Laptop("Apple MacBook Pro", 80000);
	}

}
