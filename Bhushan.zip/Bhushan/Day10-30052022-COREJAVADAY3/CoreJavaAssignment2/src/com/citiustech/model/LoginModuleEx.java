package com.citiustech.model;

import java.util.Scanner;

public class LoginModuleEx {
	public static boolean validate(String role) {
		Scanner input = new Scanner(System.in);
		boolean isValid=false;
		if (role.equalsIgnoreCase("admin")) {
			Customer[] listOfAdmin = new Customer[3];
			listOfAdmin[0] = new Customer("admin1", "password1");
			listOfAdmin[1] = new Customer("admin2", "password2");
			listOfAdmin[2] = new Customer("admin3", "password3");
			System.out.println("Please enter the username");
			String adminName = input.next();
			System.out.println("Please enter the password");
			String adminPass = input.next();
			for (int i = 0; i < listOfAdmin.length; i++) {
				if (listOfAdmin[i].getUserName().equals(adminName) && listOfAdmin[i].getPassword().equals(adminPass)) {
					System.out.println("-------------Admin menu------------------");
//					System.out.println("1.Add Product\n2. Update Product\n3. Delete Product\n4. Get Product by ID\n5. Get All Products\n6. Add customer\n7. Update Customer Information\n8. Delete Customer\n9. Get Customer by ID\n10. Get All Customer\n0. Exit");
					isValid=true;
					return true;
				}
			}
			if(!isValid) {
				System.out.println("-------------Wrong credentials----------");
				return false;
			}
		}
		
		if (role.equalsIgnoreCase("customer")) {
			Customer[] listOfCustomers = new Customer[3];
			listOfCustomers[0] = new Customer("customer1", "custPassword1");
			listOfCustomers[1] = new Customer("customer2", "custPassword2");
			listOfCustomers[2] = new Customer("customer3", "custPassword3");
			System.out.println("Please enter the username");
			String custName = input.next();
			System.out.println("Please enter the password");
			String custPass = input.next();
			for (int i = 0; i < listOfCustomers.length; i++) {
				if (listOfCustomers[i].getUserName().equals(custName) && listOfCustomers[i].getPassword().equals(custPass)) {
					isValid=true;
					return true;
				}
			}
			if(!isValid) {
				System.out.println("-------------Wrong credentials----------");
				return false;
			}
		}
		
		return false;
	}
}
