package com.citiustech.model;

import java.util.Scanner;

import com.citiustech.utility.CategorySelection;

import java.util.InputMismatchException;

public class ShoppingApplication {

	public static void main(String[] args) {
		try {
			boolean exitFlag = false;
			int menu;
			Scanner input = new Scanner(System.in);
			do {
				System.out.println("Please select the role from the menu");
				System.out.println("--------Menu--------\n1.Admin\n2.Customer\n3.Exit");
				menu = input.nextInt();
				if (menu == 1 || menu == 2 || menu == 3) {
					exitFlag = true;
				}
			} while (exitFlag != true);
			if (menu == 1) {
				System.out.println("-------------Admin module------------------");
				boolean isAdminValidated = LoginModuleEx.validate("admin");
				if(isAdminValidated) {
					System.out.println("1. Add Product\n2. Update Product\n3. Delete Product\n4. Get Product by ID\n5. Get All Products\n6. Add customer\n7. Update Customer Information\n8. Delete Customer\n9. Get Customer by ID\n10. Get All Customer\n0. Exit");
				}
			} else if (menu == 2) {
				System.out.println("-------------Customer module---------------");
				boolean isCustomerValidated = LoginModuleEx.validate("customer");
				if(isCustomerValidated) {
					System.out.println("------------Select Category--------------");
					System.out.println("Customer validation successful");
					CategorySelection.selectCategory();
				}
			} else if (menu == 3) {
				System.out
						.println("-------------Bye!!!! Thank you for shopping with us.Have a great day---------------");
			}
		} catch (InputMismatchException inputException) {
			System.out.println(
					"OOPS!!!!!!! Please enter a number from the menu.Thank you for shooping with us.Please try again");
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
			System.out.println("OOPS!!!! Something went wrong.Please try again later");
		}
	}
}
