package com.citiustech.dao;

import java.util.List;

import com.citiustech.model.Laptop;
import com.citiustech.model.Product;

public abstract class ProductsFromDatabase {
	public abstract List<Product> getProducts();
	public abstract List<Product> getProductsById();
	public abstract List<Product> getProductDetails(int product_type);
}
