package com.citiustech.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.citiustech.model.Product;

public class ProductsFromDatabaseImpl extends ProductsFromDatabase{
	static Connection con=null;
	static Scanner input = new Scanner(System.in);
	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductsById() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductDetails(int product_type) {
		try {
			con=DriverManager.getConnection("jdbc:sqlserver://IMCHBCP73-BLL;databaseName=preimpactdatabase;user=sa;password=password_123");
			PreparedStatement pstmt = con.prepareStatement("select * from Product where product_type=?");
			pstmt.setInt(4, product_type);
			ResultSet rs = pstmt.executeQuery();
			List<Product> productList = new ArrayList<Product>();
			Product product = new Product();
			while(rs.next()) {
				System.out.println(rs.getInt("product_id")+"--"+rs.getString(2)+"--"+rs.getFloat(3));
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setProductPrice(rs.getDouble(3));
				productList.add(product);
			}
			pstmt.close();
			con.close();
			return productList;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("SQL exception occured while trying to fetch LaptopDetails.Please try again later!!!");
		}
		return null;
	}

}
