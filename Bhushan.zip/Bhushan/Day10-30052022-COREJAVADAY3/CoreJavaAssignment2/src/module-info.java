module CoreJavaAssignment2 {
	requires java.sql;
}