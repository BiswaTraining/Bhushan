class Student{
	private int id;
	private String name;
	//getter for id
	public int getId(){
	System.out.println("This is Get Method");
	//validation
	return id;
	}
	//setter for id
	public void setId(int id){
	this.id=id;
	}
	//getter for name
	public String getName(){
	return name;
	}
	//setter for name
	public void setName(String name){
	this.name=name;
	
	}
	
}

class MyMainClass{
	public static void main(String [] args){
	
	Student student1 = new Student();
	student1.setId(101);
	System.out.println(student1.getId());
	}

}