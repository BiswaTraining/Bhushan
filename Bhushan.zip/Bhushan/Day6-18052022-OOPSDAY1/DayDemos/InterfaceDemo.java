interface MyInterface{
	default void method1(){
	
	}

	static void method3(){
	}
	//public abstract void method1();
	public void method2();
}
