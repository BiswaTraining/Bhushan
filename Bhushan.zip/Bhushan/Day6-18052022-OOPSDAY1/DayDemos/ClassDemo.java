class Person{
int unique_id;
String name;
String city;
int age;
String gender;

public void eat(){
System.out.println("person usually eat twice");		
}
}

class MainClass{
	public static void main(String [] args){
	Person person1 = new Person();
	person1.unique_id=101;
	person1.name="John";
	person1.city="Delhi";
	person1.age=25;
	person1.gender="Male";
	System.out.println(person1.unique_id+"-"+person1.name+"--"+person1.city);
	person1.eat();
	System.out.println("---------------------------");
	Person person2 = new Person();
	person2.unique_id=102;
	person2.name="Dessy";
	person2.city="Pune";
	person2.age=35;
	person2.gender="Female";
	System.out.println(person2.unique_id+"-"+person2.name+"--"+person2.city);
	person2.eat();
	}

}
