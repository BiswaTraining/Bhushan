class Uncle{

}


//single level Inheritance
class Parent{
public void method1(){
System.out.println("This is Parent");
}
}
class Child extends Parent,Uncle
{
public void method2(){
System.out.println("This is Child");
}
}

class GrandChild extends Child{
public void method3 (){
System.out.println("This is Child");
}
}


class InheritanceMain{
public static void main(String [] args){
	//case 1
	Parent obj = new Parent();
	obj.method1();
	//obj.method2();

	//case 2
	Child obj2 = new Child();
	obj2.method1();
	obj2.method2();

	// case 3 
	Parent obj3 = new Child();
	obj3.method1();
	//obj3.method2(); //cE
	
	//case 4 is not possible.
	//Child obj4 = new Parent();
}
}