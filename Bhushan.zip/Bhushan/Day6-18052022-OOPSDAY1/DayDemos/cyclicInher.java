class B extends A{
}

class A extends B{
}