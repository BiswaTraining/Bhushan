abstract class MyClass{
	public abstract void getNumberOfWheels();
}