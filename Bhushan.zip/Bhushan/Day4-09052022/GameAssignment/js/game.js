//Generate the random number
let secretNumber=Math.trunc(Math.random()*20)+1;
console.log(secretNumber);
//Store the maximum number of attempts locally
let maxAttempts=10;
let wrongAttempts=0;
let highestScore=0;
let score=0;

//function to check whether the input is equal to the secret number
function check(){

//Check wheter maximum number of attempts have expired
if(maxAttempts>0){
//let num = document.querySelector('#inputField').value;
let num = document.getElementById('inputField').value;
        //Checks whether the variable is null in javascript
        if(!num){
            console.log("I am here");
            document.querySelector('.message').innerHTML='The field cannot be blank.Please enter a number between 1 and 20';
            document.querySelector('.message').style.backgroundColor='Yellow';
            return;
        }

        if(num==secretNumber){
        console.log("Congratulations");
        score=20-wrongAttempts;
        console.log(score);
        if(score>highestScore){
            highestScore=score;
        }
        document.querySelector('.message').innerHTML='Congratulations';
        document.querySelector('.message').style.backgroundColor='Green';
        document.querySelector('#gameBody').style.backgroundColor='Green';
        document.querySelector('.score').innerHTML=score;
        //Once score is displayed, reset the values in background
        maxAttempts=10;
        wrongAttempts=0;
        score=0;
        secretNumber=Math.trunc(Math.random()*20)+1;
        console.log(`Highest score after reset${highestScore}`);
        console.log(`Maximum attempts left after reset ${maxAttempts}`);
        console.log(`Wrong attempts after reset ${wrongAttempts}`);
        console.log(`Secret Number after reset ${secretNumber}`);
        }
        else if(num<secretNumber){
        console.log("Too Low");
        maxAttempts--;
        wrongAttempts++;
        score=20-wrongAttempts;
        console.log(`Maximum attempts left ${maxAttempts}`);
        console.log(`Count of wrong attempts ${wrongAttempts}`);
        console.log(`Number is ${num}`);
        document.querySelector('.message').innerHTML='OOPS!!! Too low';
        document.querySelector('.message').style.backgroundColor='Red';
        document.querySelector('#gameBody').style.backgroundColor='grey';
        }
        else{
        console.log("Too High");
        maxAttempts--;
        wrongAttempts++;
        score=20-wrongAttempts;
        console.log(`Maximum attempts left ${maxAttempts}`);
        console.log(`Count of wrong attempts ${wrongAttempts}`);
        document.querySelector('.message').innerHTML='OOPS!!! Too High';
        document.querySelector('.message').style.backgroundColor='Red';
        document.querySelector('#gameBody').style.backgroundColor='grey';
        }
        //If maximum number of attempts have expired, then reset the value of maximum attempts left, generate a new random number
        if(maxAttempts==0){
        maxAttempts=10;
        wrongAttempts=0;
        score=0;
        secretNumber=Math.trunc(Math.random()*20)+1;
        //Display score as 0 if all te attempts have exhausted
        document.querySelector('.score').innerHTML=score;
        console.log(`Highest score after reset${highestScore}`);
        console.log(`Maximum attempts left after reset ${maxAttempts}`);
        console.log(`Wrong attempts after reset ${wrongAttempts}`);
        console.log(`Secret Number after reset ${secretNumber}`);
        }
        //update the highest score and score after every click
        document.querySelector('.highestScore').innerHTML=highestScore;
        //document.querySelector('.score').innerHTML=score;
    }   
}

function reset(){
    maxAttempts=10;
    wrongAttempts=0;
    score=0;
    secretNumber=Math.trunc(Math.random()*20)+1;
    //Set score to 0 once the data is reset excluding the highest score
    document.querySelector('.score').innerHTML=score;
    //Suppose the user continues to play on after the correct guess, 
    //then values would be canged to default,but bakground would still be green,
    //so we need to explicitly change the body background as well as the message background and its content
    document.querySelector('#gameBody').style.backgroundColor='grey';
    document.querySelector('.message').innerHTML='';
    document.querySelector('.message').style.backgroundColor='grey';
    console.log(`Highest score after reset${highestScore}`);
    console.log(`Maximum attempts left after reset ${maxAttempts}`);
    console.log(`Wrong attempts after reset ${wrongAttempts}`);
    console.log(`Secret Number after reset ${secretNumber}`);
}

let inputFromUser =document.getElementById('inputField');
inputFromUser.addEventListener("input",validateInput);
//Here in the above statement "input" is an event like click.So, in addEventListener method we use event as the first parameter

function validateInput(){
    if(inputFromUser.value<1 || inputFromUser.value>20){
        console.log("Please enter a number between 1 and 20(Both included)");
        //window.print("Please enter a number between 1 and 20(Both included)");
        /*const element = document.createElement('p')
        const elementText = document.createTextNode('Please enter a number between 1 and 20(Both included)');
        element.appendChild(elementText);
        document.body.appendChild(element);*/
        document.querySelector('.validationMessage').textContent = 'Please enter a number between 1 and 20(Both included)';
        document.querySelector('.validationMessage').style.backgroundColor = 'Yellow';
    }
}