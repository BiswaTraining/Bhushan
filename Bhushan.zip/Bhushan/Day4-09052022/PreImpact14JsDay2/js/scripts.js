//----------------------------Understanding of Arrays
// let student1_name="James";
// let student2_name="Kevin";
// let student3_name="John";

// //declaring array
// //way 1
// const students = ['James', 'Kevin','John'];
// //                  0         1      2
// //way 2
//const employees = new Array('James','Kevin','John');
// //                            0         1      2
// //length                      1         2      3


// employees[0]='Simon';

// console.log(students[1]);
// console.log(employees);

// //operations on Array
// console.log("Length of Array ="+employees.length);

// // I want to fetch John
// console.log(employees[employees.length-1]);

// employees[3]="Jason";
// employees[4]="Zanillia";
// employees[5]="Lin";
// console.log(employees);


// //some common methods of Array in JS
// //push - at the end
// employees.push("Micheal");
// console.log(employees);

// //unshift -- add element at begining.
// employees.unshift("Eric");
// console.log(employees);

// //pop - delete last element
// employees.pop();
// console.log(employees);

// //shift
// employees.shift();
// console.log(employees);

// //index of
// console.log("Index of Kevin ="+employees.indexOf("Kevin"));

// //includes
// console.log(employees.includes("Bhushan"));


// const fname="Bhushan";
// const bhushan_details=[fname,'Kumar',2022-1980,'Doctor',employees];
// console.log(bhushan_details);

// const nexon=[12345,'Red',13.5,'EV',2022]

// ----------------------------------------- Objects
// WE will take object as Tata Nexon
// const tataNexon={
//     chesisNumber:12345,
//     carColor:"Red",
//     carPrice:13.5,
//     carFeatures:'EV',
//     yearOfMan:2022
// }
// console.log(tataNexon);
// console.log("Chesis Number ="+tataNexon.chesisNumber+" Car Color ="+tataNexon.carColor);

// //  fetchig anf changing values using '.' operator
// //change values of Key "Car Color" 
// tataNexon.carColor="Blue";
// tataNexon.carPrice=15;
// console.log("Car Color = "+tataNexon.carColor+" Price="+tataNexon.carPrice);

// //  fetchig anf changing values using '[]' operator
// console.log("Feature ="+tataNexon['carFeatures']);
// tataNexon['carColor']="White";
// console.log(tataNexon['carColor']);

// tataNexon['carSegment']="Compact SUV";
// console.log(tataNexon);

// tataNexon.carWeight=1200;
// console.log(tataNexon);









