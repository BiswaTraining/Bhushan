console.log(document.querySelector('.mh1').innerHTML);

console.log(document.querySelector('.mh1').textContent);


console.log(document.querySelector('#ih2').textContent);



console.log(document.getElementById('ih2').innerHTML);
let info = document.getElementsByClassName('mh1');
console.log(info[0].innerHTML);


let info2 = document.getElementsByClassName('myPara');
console.log(info2[0].innerHTML);

//event on button
document.querySelector('.myButton').addEventListener('click',function(){
    // alert("You have clicked button");
    console.log(document.querySelector('.age').value);
    document.querySelector(".nage").textContent=document.querySelector('.age').value;

});

document.querySelector(".myButton2").addEventListener('click', function(){
    const cmh1 = document.querySelectorAll('.mh1');
    console.log(cmh1[1].innerHTML);
    cmh1[1].textContent="Changed";

    document.querySelector('body').style.backgroundColor="green";
    
    document.querySelector('.mh1').textContent="James";
    document.querySelector('.mh1').style.color="White";

    document.querySelector('#ih2').textContent="John";
});