//storing values in local storage
localStorage.setItem("username","Bhushan");
localStorage.password="Bhushan";

//accessing the local storage 
document.getElementById('myp1').innerHTML="Welcome"+localStorage.username;

//Validation
document.querySelector('#submit').addEventListener('click',function(){
if(document.getElementById('username').value===localStorage.username &&
document.getElementById('password').value===localStorage.password ){
    alert("Successfully Login");
}
else{
    document.write("Wrong Credentials");
}
});