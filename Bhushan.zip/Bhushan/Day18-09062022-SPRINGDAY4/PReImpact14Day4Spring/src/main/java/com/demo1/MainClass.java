package com.demo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfiguration.class);
		SpElEx sp = context.getBean("sp",SpElEx.class);
		System.out.println(sp);
		
		SpelExpressionParser expr = new SpelExpressionParser();
		Expression expression = expr.parseExpression("(4009+45)/(32*2)");
		System.out.println(expression.getValue());
		
	}

}
