package com.demo3.Dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo3.model.Emp;

public class EmployeeDaoImpl implements EmployeeDao{
	
	private JdbcTemplate jdbcTemplate;
	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insert(Emp emp) {
		String query= "insert into emp values(?,?)";
		int rows = this.jdbcTemplate.update(query, emp.getEmp_id(),emp.getEmp_name());
		return rows;
	}

	public int updateEmp(Emp emp) {
		String query = "update emp set emp_name=? where emp_id=?";
		int rows =this.jdbcTemplate.update(query,emp.getEmp_name(),emp.getEmp_id());
		return rows;
	}

	public int deleteEmp(Emp emp) {
		String query = "delete from emp where emp_id=?";
		int rows = this.jdbcTemplate.update(query,emp.getEmp_id());
		return rows;
	}
	//Display one Employee 
	public Emp getEmp(int emp_id) {
		String query = "select * from emp where emp_id=?";
		RowMapper<Emp> rowMapper = new RowMapperImpl();	
		Emp emp =this.jdbcTemplate.queryForObject(query, rowMapper,emp_id);
		return emp;
	}

	public List<Emp> getAllEmployees() {
		String query = "select * from emp";
		List<Emp> emp =this.jdbcTemplate.query(query, new RowMapperImpl());
		return emp;
	}

}
