package com.demo2;

public class PaymentServiceImpl{

	//join point
	//before
	public void payment(int amount) {
		System.out.println("Payment Started");
		System.out.println("Working");
		System.out.println("Payment Done...............");
		
	}
	//after
	//join point

}
