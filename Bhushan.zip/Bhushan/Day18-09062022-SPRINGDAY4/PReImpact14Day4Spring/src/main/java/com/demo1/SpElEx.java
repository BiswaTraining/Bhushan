package com.demo1;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("sp")
public class SpElEx {
	
	public int myFavId;
	
	//expression
//	@Value("#{20+4}")
	//static variable
//	@Value("#{T(com.demo1.SpElEx).myFavId}")
	@Value("#{new com.demo1.SpElEx().myFavId}")
	//Object
//	@Value("#{new java.lang.Integer(24)}")
	// static method
//	@Value("#{T(com.demo1.SpElEx).getNumber()}")
	private int emp_id;
	@Value("John")
	private String name;
	@Value("#{T(com.demo1.JavaConfiguration).departments()}")
	private List<String> departments;


	@Override
	public String toString() {
		return "SpElEx [emp_id=" + emp_id + ", name=" + name + ", departments=" + departments + "]";
	}


	public int getEmp_id() {
		return emp_id;
	}


	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<String> getDepartments() {
		return departments;
	}


	public void setDepartments(List<String> departments) {
		this.departments = departments;
	}
	
	public static int getNumber() {
		return 20;
	}

}
