package com.demo3.view;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.demo3.Dao.EmployeeDao;
import com.demo3.Dao.EmployeeDaoImpl;
import com.demo3.Dao.JavaConfigurationClass;
import com.demo3.model.Emp;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfigurationClass.class);
		EmployeeDao empDao =context.getBean("empDao",EmployeeDao.class);
//		ApplicationContext context = new ClassPathXmlApplicationContext("com/demo3/Dao/bean.xml");
//		EmployeeDao empDao =context.getBean("empDao",EmployeeDao.class);
		//insert Operation
//		Emp emp = new Emp();
//		emp.setEmp_id(103);
//		emp.setEmp_name("Kim");
//		int rows =empDao.insert(emp);
//		System.out.println(rows+" inserted");
		
		//update 
//		Emp emp = new Emp();
//		emp.setEmp_id(102);
//		emp.setEmp_name("Simon");
//		int row = empDao.updateEmp(emp);
//		System.out.println(row +"Updated");
		
		//delete
//		Emp emp = new Emp();
//		emp.setEmp_id(102);
//		empDao.deleteEmp(emp);
//		System.out.println("Deleted");
		
		//Display One Employee
//		Emp emp1 = empDao.getEmp(101);
//		System.out.println(emp1.getEmp_id()+"--"+emp1.getEmp_name());
		
		//Display All Employees
		List<Emp> emp = empDao.getAllEmployees();
		for(Emp e:emp) {
			System.out.println(e.getEmp_id()+"---"+e.getEmp_name());
		}
		
		
		
		
	}

}
