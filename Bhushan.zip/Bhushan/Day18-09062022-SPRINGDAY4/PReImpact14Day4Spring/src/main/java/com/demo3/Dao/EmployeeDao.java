package com.demo3.Dao;

import java.util.List;

import com.demo3.model.Emp;

public interface EmployeeDao {
	
	public int insert(Emp emp);
	public int updateEmp(Emp emp);
	public int deleteEmp(Emp emp);
	//get only single row
	public Emp getEmp(int emp_id);
	//to get all employees
	public List<Emp> getAllEmployees();

}
