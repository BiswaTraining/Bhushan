package com.demo2;

import java.util.Scanner;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {
	
	static Scanner input = new Scanner(System.in);
	
	
	//Advice 1
	@Before("execution(* com.demo2.PaymentServiceImpl.payment(*))")
	public void isValid() {
		System.out.println("Enter Username");
		String uname= input.next();
		System.out.println("Enter Password");
		String password= input.next();
		if(uname.equals("admin")&& password.equals("admin")) {
			System.out.println("You are Validated");
			System.out.println("Make Payment");
		}
		else {
			System.out.println("You are Not Validated");
			System.exit(0);
		}
	}
	
	//Advice 2
	@After("execution(* com.demo2.PaymentServiceImpl.payment(*))")
	public void successMessage() {
		System.out.println("Transaction done Successfully......");
	}

}
