package com.demo1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.demo1")
public class JavaConfiguration {
	static List<String> departments = new ArrayList<String>();
	public static List departments(){
		departments.add("HR");
		departments.add("Finanace");
		
		return departments;
	}

}
